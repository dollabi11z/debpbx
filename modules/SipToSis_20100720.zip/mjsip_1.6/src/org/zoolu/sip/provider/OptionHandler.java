package org.zoolu.sip.provider;

public interface OptionHandler
{
    String onOptionMsgReceived();
}
