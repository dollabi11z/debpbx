package local.media;



/** JMediaReceiverListener.
  */
public interface JMediaReceiverListener
{   
   public void controllerUpdate(javax.media.ControllerEvent event);  
}


