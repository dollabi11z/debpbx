These scripts are for compiling mjsip and siptosis only.
See the root siptosis readme.txt for limited skype4java compiling instructions.

For the compile to work complete with GSM support, you will need to download a couple of libraries:
1. Sun's JMF from http://java.sun.com/javase/technologies/desktop/media/jmf/2.1.1/download.html and copy the jmf.jar file to siptosis root
2. Download tritonus_gsm-0.3.6.jar and tritonus_share-0.3.6.jar from http://tritonus.org and put in siptosis root.

Then set dojmf=1 and/or dotritonus=1 in the compile script for your platform.

Run the compile script for your platform.
You will see many warning messages. That is normal.
If you see error messages, that must be corrected for a successful compile.

