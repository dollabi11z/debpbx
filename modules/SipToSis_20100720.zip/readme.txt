Copyright (C) 2009 Greg Dorfuss - mhspot.com

SipToSis is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.
 
SipToSis is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this source code; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
Based on mjsip 1.6 software.
Uses skype4java and log4j libraries.
mjsip, skype4java and log4j have their own license agreements.

This product uses the Skype API but is not endorsed, certified or otherwise approved in any way by Skype

Installation:

Install java 1.5 or higher for your platform - make sure it is available in the system path.
You can check the version from a command prompt like this: java -version


For new install:
    Windows/Linux:
	   Unzip the siptosis archive into a folder called siptosis or other folder name.
	OSX:
	   Make a folder /Applications/siptosis and copy archive contents there.
For an upgrade:
    Make a backup copy of your existing installation.
    Unzip new archive over your existing installation.
    For Windows: 
    	Delete skype.dll - The basic installer will copy a new one from the samples folder.
    For Linux: 
        Delete libskype.so if you have not previously compiled your own native connector based on my latest skype4java. 
        If my precompiled versions won't run on your system then follow the compile procedure described later in this document.
        
	All Platforms:    
 	   Add new parameters as needed - see changes.txt for changes made since your previous version.

Startup Skype (must be the same computer).

Windows:
	double click SipToSis_win.bat
	If you get warning about JAVAEXEPATH on Windows 64 bit with 64 bit Java:
	  edit SipToSis_win.bat and uncomment the line "set JAVAEXEPATH" - make sure it points to your JRE or JDK bin folder.
OSX:
	Go to Application/siptosis 
	Double click SipToSis_osx
Linux:
    chmod +x SipToSis_linux - one time only to grant execute permission.
	./SipToSis_linux
	NOTE: Pulse audio is not recommended due to high cpu and should be uninstalled or disabled.
	For automatic boot:
		There is a script stsTrunk_linux (do not rename it) for easier booting it works similar to the multiple channel script for stsTrunkBuilder.
		This script starts Skype, Siptosis and also optionally XVFB or VNC. 
		chmod +x stsTrunk_linux so it can executed.
		You MUST set variables runuser and scriptpath in this script for your environment.
	    Supported commands start, stop, status, snapscreen, config or boot
		  edit /etc/rc.local (sudo vi (gedit) /etc/rc.local)
		  Add following line before exit 0: 
		       su -l SipToSisOsUser -c "/home/SipToSisUser/SipToSis/stsTrunk_linux boot" 
		    Change 'SipToSisOsUser' to the actual os user name and 'SipToSis' to the actual folder name.
		  Note: if using snd-dummy, make sure modprobe is before siptosis startup command.
		  If sound device is not found only at boot time, add user to audio group: /etc/group
		     Example: audio:blahblah:pulse,someuser 
		       or adduser username audio
		  If the sound errors about hdmi etc. from skype bug you, edit /usr/share/alsa/alsa.conf (backup first) and comment out:
		     /usr/share/alsa/pulse.conf
		     /usr/share/alsa/bluetooth.conf
		     pcm.hdmi cards.pcm.hdmi
		  If you have trouble with the boot process, numerous diagnostic files get stored in siptosis/log at boot time.
	
	
The Skype program may ask if access should be allowed. If you don't authorize it, it will not work.
You usually have to go into the Skype client and manually authorize it in the options screen
(Even though you clicked allow access - some sort of skype bug - depends on skype version).
Your Skype User Id should appear on the console. If not stop and fix problem.

If the SipToSis console shows a contact_url of 127.0.0.1 instead of the machine's actual IP address, 
edit the siptosis.cfg file, comment out the "#Sample AUTO config with NO registration" section 
and setup the "#Sample config with NO registration" section by setting 127.0.0.1 to the SipToSis machine's IP address
and also set the via_addr. If you know what you are doing, you can enable one of the other registration sections instead. 


Now setup your VOIP/SIP adapter or PBX to call the SipToSis Computer.

SPA-3102 Dial Plan Example and other Linksys sipura devices:
	(<#1:>xx.<:@siptosisIpAddress:siptosisHostPort>|originaldialplan)
	At this point, dialing #155 should get you the Skype Echo Test service.
	Only the Skype Echo Test service and PSTN is callable at this point.
	You will customize this later on.
	
Asterisk Peer Example:
In sip.conf	
[siptosisuser]
username=siptosisuser
type=friend
context=default
secret=siptosisregpassword
host=dynamic
nat=no
dtmfmode=auto
;canreinvite=yes (use only if you understand what it does - does not work well with ilbc and speex codecs)
canreinvite=no
;port should not be needed if you register with the PBX - some have said it's needed??
;port=siptosishostport
qualify=yes
defaultip=siptosisip
incominglimit=1
outgoinglimit=1
call-limit=1
busylevel=1

Asterisk Single channel config that can be put in extensions.conf
exten => _7X.,1,Dial(SIP/siptosisuser/${EXTEN:1})
;you would then dial 7 and the number you want to call

** Customize and authorize for regular dialing:
   Assign speed dial numbers in the Skype client to each Skype contact you want to call. 
   or create mappings in SipToSkypeAuths.props. 
   You don't need to do this if using only skypeout.
   If using a PBX you could map extensions to Skype users there instead. 

   Edit SipToSkypeAuth.props to forward and authorize SIP calls to desired Skype destinations. (Most users will only use: *,*,localnet,calleeid)
   Edit SkypeOutDialingRules.props for any Skype dialing rules/transforms wanted.
   Edit SkypeToSipAuth.props to forward skype calls to SIP destinations (failure to do this step will cause all incoming Skype calls to get the invalid destination message).

At this point, you should be able to make and receive skype calls. The remainder of this document contains
some optional configuration and troubleshooting instructions. More documentation is available on http://mhspot.com


CallBack config:
   *** CHECK LEGALITY OF USING CALLBACK FOR YOUR COUNTRY *** USE AT YOUR OWN RISK ***
   Compatability:
     Windows client 4.1.0.141 works fine.
     Linux client 2.1.0.47 does not support two stage callback with Skype as originator and a Skype target.
     Linux client 2.0.0.72 has not been tested but I expect it to work.
   Callbacks can be initiated from SIP and Skype DIDs assuming Caller Id works with the DID or can be initiated from Skype User.
   See sample files SipToSkypeAuth.props,SkypeOutDialingRules.props,SkypeToSipAuth.props for examples.
   Two stage dialing requires the SkypeInBand decoder turned on:
      enableSkypeDtmfDetector=yes
      inbandFullTimeDtmfDetection=yes

Conference Calls:
   Compatability:
     Windows client 4.1.0.141 works fine.
     Linux client 2.1.0.47 seems to have some audio problems.
     Linux client 2.0.0.72 has not been tested but I expect it to work.
   See sample files SipToSkypeAuth.props and SkypeOutDialingRules.props for examples.

Codec Configuration:
  GSM Codec:
    To use Tritonus download tritonus_gsm-0.3.6.jar and tritonus_share-0.3.6.jar from tritonus.org and put in same folder.
    To use Sun's JMF , download Sun's Java Media Framework and put jmf.jar in same folder. 
  PCMU(u-law),PCMA(a-law),iLBC Codecs
    Already built in

  See the siptosis.cfg file and look for audio_codec= to configure codecs and sound volume.

You can specify a different config file like this:
   SipToSis_win.bat myotherconfig.cfg	

For a multi channel trunk, you might want to try stsTrunkBuilder.
   
To see full debug information set the following in siptosis.cfg
logConfigFile=log_debug.properties
and for Skype API tracing:
skypeAPITrace=yes

On Windows: 
     If you get the unsatisfied link error "Can't load IA 32-bit .dll on a AMD 64-bit platform"
     delete skype.dll and let the installer copy the correct one in.

On Linux: 
     If you have startup issues, set logConfigFile parameter to log_debug.properties in siptosis.cfg
     look for javaLibPath: on the console or log file - it contains
     the skype4java search path for libskype.so. The skype.jar file is checked last.
     Make sure there are no other copies of the lib. 
     The default libskype.so is IA 32bit, the installer should copy in the correct version.
     The connectors were compiled with with the latest gcc so you may have dependency issues.
     ldd libskype.so to show the dependencies. 
     If needed, compile your own version and put it in one of the search locations. 
     Basic libskype.so compiling instructions:
        You need a java JDK not a JRE to do this procedure. (Ubuntu: sudo apt-get install sun-java6-jdk)
        #You can download the lastest skype4java source from their site or use my Skype4Java.zip as the source.
        #I strongly suggest you use my skype4java source since it has some reliability improvements.
		$ su (need root access)
		    enter root password
		#-- if you don't have gcc and g++, do next command  (centos example)  
		$ yum install gcc-c++
		 	(or for ubuntu sudo apt-get install g++ to get linker)
		#-- if you don't have X development libraries, do next command too (centos example)
		$ yum -y groupinstall "X Software Development"
		      (or for Ubuntu $ sudo apt-get -y install xorg-dev)
		$ exit (get out of root)
		$ export LANG=C
		$ If using their source, tar -xzvf skype4java_1.0b.tar.gz otherwise use the extracted zip source.
		$ cd skype/skype/src_linux

        # Edit the Makefile to work with your environment.
		$ vim Makefile
		# change JDK_DIR to your jdk location (/usr/java/jdk1.6.0_10/) depends on your system's jdk install.
		The following changes are also needed if using their source.
		# append -fPIC to the existing CFLAGS if missing
		# Add skype.jar to the classpath which is not included by default
		# javah -classpath .:../release/skype.jar com.skype.connector.linux.SkypeFramework 
		
		$ make
        #If their source doesn't compile, figure it out or contact the skype4java developers for more help.
        #If using my source, post the problem on my forum.
		$ file ../res/libskype.so
		   libskype.so: ELF 64-bit LSB shared object, AMD x86-64, version 1 (SYSV), not stripped
		   The above information will be different depending on your system.
        #Now copy libskype.so over to the SipToSis root folder.
		$ cp ../res/libskype.so ~/siptosis/

On OS X: 
         If you have startup issues:
         Only 32 bit java 1.5 or higher will work on OSX.
		 Make sure the Skype.framework got copied into /Library/Frameworks/
		 If not, manually copy it. From the Applications/siptosis folder run the following command:
		   cp -r samples/osx_framework/Skype.framework /Library/Frameworks/Skype.framework
		 Set logConfigFile parameter to log_debug.properties in siptosis.cfg
         look for javaLibPath: on the console or log file - it contains
         the skype4java search path for libskype.jnilib. The skype.jar file is checked last.
         Make sure there are no other copies of the lib. 
        
		 I'm not sure about the following procedure to avoid recompiling libskype.jnilib.
		 From this program folder:
		 /PathToTool/otool -L libskype.jnilib
		   fix paths of each wrong lib path with following commands 
		   /PathToTool/install_name_tool -change /wrongpath/somelib /correctpath/somelib	libskype.jnilib
		 Then do this:
		   /PathToTool/install_name_tool -id @loader_path/libskype.jnilib libskype.jnilib
		 The other option is to try putting each lib in the correct location.
        
         You may need to compile your own libskype.jnilib
         Download lastest skype4java source from their site.
         The code is in the skype/skype/src_osx folder.
         See link below for some compiling help.
         http://developer.apple.com/documentation/Java/Conceptual/Java14Development/05-CoreJavaAPIs/CoreJavaAPIs.html
		 Look at the JNI section.
		 Sorry, I can't offer more help than this 
         - contact skype4java developers for more help.

