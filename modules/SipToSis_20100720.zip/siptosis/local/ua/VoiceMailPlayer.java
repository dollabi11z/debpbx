package local.ua;

import org.apache.log4j.Logger;

import com.skype.Skype;
import com.skype.SkypeException;
import com.skype.VoiceMail;
import com.skype.VoiceMailStatusChangedListener;

public class VoiceMailPlayer extends Thread implements VoiceMailStatusChangedListener
{
	private SSCallChannel controller=null;
	private Logger log = null;
	private volatile VoiceMail.Status curVmStatus=VoiceMail.Status.UNKNOWN;
	private VoiceMail[] voiceMails=null;
	private VoiceMail curVm=null;
	private volatile int vmIndex=-1;
	private volatile boolean stopped=false;
	private SkypeProfile skype_profile=null;
	private volatile boolean vmDeleted=false;
	private volatile boolean forcedStop=false;
	private volatile boolean dtmfOperationPending=false;
	private String curVMPartner=null;
	private boolean playCalled=false;

	VoiceMailPlayer(SSCallChannel argController,SkypeProfile argSkype_profile)
	{
		this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		log = Logger.getLogger(this.getName());
		controller=argController;
		skype_profile=argSkype_profile;
		start();
	}
	
	
	public void stopPlayer()
	{
		stopped=true;
		log.info("VMP: Stopping VoiceMail player");
	 	forcedStop=true;
		stopPlayBack();
		releaseVoiceMail();
	}
	
	public void run()
	{
		voiceMailRetrieve();
	}
	
	public void gotDtmf(int digit)
	{
		 controller.ua.clearDtmfBuffer();
		 
		 log.debug("# VMP DTMF "+digit);
		 
		 if (dtmfOperationPending)
		 {
			 log.debug("# VMP DTMF command pending - ignored");
             return;
		 }
		 
		 switch (digit)
		 {
		 case 1:
			   // continue to next message
		           dtmfOperationPending=true;
			       controller.ua.skypeRtpSender.stopSipClips();
			       forcedStop=true;
				   stopPlayBack();
				   releaseVoiceMail();
				   playNextVoiceMail();
			       dtmfOperationPending=false;
				   break;
		 case 2:
			   // replay
			 	   dtmfOperationPending=true;
			 	   controller.ua.skypeRtpSender.stopSipClips();
			 	   forcedStop=true;
				   stopPlayBack();
				   releaseVoiceMail();
				   //try {sleep(200);}catch (Exception e){}
				   vmIndex--;
				   playNextVoiceMail();
			       dtmfOperationPending=false;
				   break;
			   
		 case 3:
			   // delete and continue
			 if (!vmDeleted)
			 {	 
		       dtmfOperationPending=true;
			   vmDeleted=true;	 
		       controller.ua.skypeRtpSender.stopSipClips();
		 	   forcedStop=true;
			   stopPlayBack();
			   try {curVm.dispose();}catch(SkypeException e){log.error("Delete Voicemail error",e);}
			 }  
		     break;
		 case 4:
		     // call back
	         dtmfOperationPending=true;
	         controller.ua.skypeRtpSender.stopSipClips();
	 	     forcedStop=true;
		     stopPlayBack();
			 releaseVoiceMail();
			 try {sleep(200);}catch (Exception e){}
			 close(false);
			 log.info("VMP: Attempting call to: "+curVMPartner);
			 if (!controller.makeSkypeCall(curVMPartner))
			 {
				 log.info("Return call to: "+curVMPartner+" failed.");
				 controller.listen();
			 }
		     break;
		 case 9:
		     // delete all
	         dtmfOperationPending=true;
	         controller.ua.skypeRtpSender.stopSipClips();
	 	     forcedStop=true;
		     stopPlayBack();
			 releaseVoiceMail();
			 controller.ua.queueSipClip(skype_profile.vmMessageDeleteAllClip);
			 for (int x=0;x<voiceMails.length;x++)
			 {		 
				try{voiceMails[x].dispose();}catch(SkypeException e){}
			 }
			 controller.waitForSipClipsComplete();
			 close(true);
		     break;

		 
		 }
	}
	
	public void statusChanged(VoiceMail.Status status) throws SkypeException
	{
		log.info("VMP: Status:"+status);
		curVmStatus=status;
		
		switch (status)
		{
		    case FAILED:
			   close(true);
			   break;
		    case PLAYED:
			   boolean forced=forcedStop;
			   controller.ua.skypeRtpSender.stopSkypeMedia();
			   try {sleep(200);}catch (Exception e){}
			   if (!forced)
				   controller.ua.queueSipClip(skype_profile.vmEndOfMessageClip);
		       break;
		    case DELETING:
			   controller.ua.queueSipClip(skype_profile.vmMessageDeletedClip);
			   controller.waitForSipClipsComplete();
			   releaseVoiceMail();
			   playNextVoiceMail();
		       dtmfOperationPending=false;
		       break;
		    case PLAYING:
		      if (!playCalled)	  
			  {
		          playCalled=true;	  
			      if (stopped)
			      {
			    	 this.stopPlayBack();   
			      }
			      else
			      {	  
				   vmDeleted=false;
				   controller.ua.clearDtmfBuffer();
				   curVMPartner=curVm.getPartnerId();
				   log.info("VM From: "+curVMPartner+" at "+curVm.getStartTime()+" for "+curVm.getDuration()+" seconds.");	
				   if (!redirVoiceMailAudio(curVm.getId()))
					   close(true);
			      }
			  }
			  break;
		}
	}
	
    private void voiceMailRetrieve()
    {
    	// find voicemails and play
		try
		{
			voiceMails=Skype.getAllVoiceMails();
		}
		catch(SkypeException se)
		{
			log.error("VMP: VoiceMail Error",se);
			close(true);
			return;
		}
		
		vmIndex=-1;
		
		if (voiceMails.length==0)
		{
		   controller.ua.queueSipClip(skype_profile.vmNoMessagesClip);
		   controller.waitForSipClipsComplete();
		   close(true);
		}
		else
		{	
		   playNextVoiceMail();
		}
    }    	

    private void close(boolean hangup)
    {
    	stopped=true;
    	
    	for (int v=0;v<voiceMails.length;v++)
    		VoiceMail.destroyInstance(voiceMails[v].getId());
    	
		controller.voiceMailClosed(hangup);
    }
    
    private void playNextVoiceMail()
    {
    	if (stopped)
    		return;

		  log.debug("# playNextVoiceMail");

		curVMPartner=null;
    	forcedStop=false;
    	playCalled=false;

    	vmIndex++;
    	if (vmIndex>=voiceMails.length)
    	{
    		log.info("VMP: No more VoiceMail");
 		    controller.ua.queueSipClip(skype_profile.vmNoMoreMessagesClip);
		    controller.waitForSipClipsComplete();
    		close(true);
    		return;
    	}

		   controller.ua.queueSipClip(skype_profile.vmPlayingClip);
		   controller.waitForSipClipsComplete();

    	if (stopped)
	    		return;
		   
		curVm=voiceMails[vmIndex];
		   
		try
		{
		   curVmStatus=VoiceMail.Status.UNKNOWN;
		   curVm.addVoiceMailStatusChangedListener(this);
		   curVm.startPlayback();
		}
		catch(Exception se)
		{
			log.error("VoiceMail Error",se);
			close(true);
		}
    }
    	
    private void releaseVoiceMail()
    {
    	if (curVm==null)
    		return;

    	log.debug("# releaseVoiceMail");
   		curVm.removeVoiceMailStatusChangedListener(this);
    	curVm=null;
    }
    
    private void stopPlayBack()
    {
    	if (curVm==null)
    		return;
    	
		log.debug("# stopPlayBack curVmStatus="+curVmStatus);

    	try
    	{
    	  curVm.stopPlayback();
    	  
		  while (curVmStatus==VoiceMail.Status.PLAYING || curVmStatus==VoiceMail.Status.UNKNOWN)
    	  {
    		  try{sleep(100);}catch(Exception e){}
    		  log.debug("# stopPlayBack curVmStatus="+curVmStatus);
    	  }
    	}
    	catch(Exception e)
    	{
    		log.error("VMP stopPlayBack Error",e);
    	}
	   
    	
        if (util.parseSkypeResponse("ALTER VOICEMAIL "+curVm.getId()+" SET_OUTPUT SOUNDCARD=\"default\"", "ALTER VOICEMAIL "+curVm.getId()).startsWith("SET_OUTPUT"))
        {	
        	log.debug("VMP: unredirVoiceMailAudio success");
        }
        else
        {
        	log.error("VMP: unredirVoiceMailAudio failed");
        } 
        
    }
    
    
    
    
    private boolean redirVoiceMailAudio(String VmId)
    {
    	if (curVm==null || stopped)
    		return false;

    	//if (util.parseSkypeResponse("ALTER VOICEMAIL "+VmId+" SET_OUTPUT PORT=\""+controller.ua.skypeOutPort+"\"", "ALTER VOICEMAIL "+VmId).startsWith("SET_OUTPUT")
        //&& util.parseSkypeResponse("ALTER VOICEMAIL "+VmId+" SET_INPUT PORT=\""+controller.ua.skypeInPort+"\"","ALTER VOICEMAIL "+VmId).startsWith("SET_INPUT"))

        if (util.parseSkypeResponse("ALTER VOICEMAIL "+VmId+" SET_OUTPUT PORT=\""+controller.ua.skypeOutPort+"\"", "ALTER VOICEMAIL "+VmId).startsWith("SET_OUTPUT"))
        {	

        	try {
            	controller.ua.skypeRtpSender.startSkypeMedia();
    	    }
        	catch(Exception e)
        	{
        		log.error("VMP stopPlayBack Error",e);
        	}
        	log.debug("VMP: redirVoiceMailAudio success");
        	return true;
        }
        else
        {
        	log.error("VMP: redirVoiceMailAudio failed");
        	return false;
        }
    }

    
    
}
