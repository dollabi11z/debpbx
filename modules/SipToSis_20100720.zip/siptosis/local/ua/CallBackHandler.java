/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Based on mjsip 1.6 software and skype4java
 * 
 * Author(s):
 * Greg Dorfuss
 */


package local.ua;

import org.apache.log4j.Logger;

import com.skype.Call;

public class CallBackHandler extends Thread 
{
	private boolean sipInitiated=false;
	private SSCallChannel callChan=null;
	private int ringTimeout;
	private Logger log = null;
	
	CallBackHandler(SSCallChannel argCallChan,boolean argSipInitiated,int argTimeoutSeconds) 
	{
		this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		log = Logger.getLogger(this.getClass().getName());
		callChan=argCallChan;
		sipInitiated=argSipInitiated;
		ringTimeout=argTimeoutSeconds;
	    start();
	}
	
	
	
	public void run()
	{
		callChan.callBackDial(handleCallBack());
	}
	
	private boolean handleCallBack()
	{
		log.info("CALLBACK - waiting for caller to hangup");
		int waitCnt=0;
		if (sipInitiated)
		{
			// wait x amount of time for sip caller to hang up
			while (callChan.ua.call_state==UserAgent.UA_INCOMING_CALL)
			{	
				log.info("SIP State="+callChan.ua.call_state);
				if (waitCnt++>ringTimeout)
				{	
					log.info("CALLBACK - timeout waiting for caller to hangup");
					return false;
				}
				try {sleep(1000);}catch(Exception e){}
			}
		}
		else
		{
			// wait x amount of time for skype caller to hang up
			try
			{
				Call skypeCall=callChan.skypeChannels.get(0).getSkypeCall();
				Call.Status SkypeCallStatus=skypeCall.getStatus();
				while (SkypeCallStatus==Call.Status.RINGING)
				{	
					log.info("Skype State="+SkypeCallStatus);
					if (waitCnt++>ringTimeout)
					{	
						log.info("CALLBACK - timeout waiting for caller to hangup");
						return false;
					}
					try {sleep(1000);}catch(Exception e){}
					SkypeCallStatus=skypeCall.getStatus();
				}
				log.debug("CallBack: Skype Call Status is: "+SkypeCallStatus); // should be MISSED
			}
			catch(Exception se)
			{
				log.error("handleCallBack Error",se);
				return false;
			}
		}
		

		return true;
	}

	
}
