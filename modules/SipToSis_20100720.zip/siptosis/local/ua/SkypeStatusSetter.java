/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Based on mjsip 1.6 software and skype4java
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;

// periodically set Skype User Status to user set status

public class SkypeStatusSetter extends Thread
{
	private long intervalMinutes=0;
	private boolean stopTimer=false;
	private String skypeStatus=null;
	
	SkypeStatusSetter(long argTimeoutMinutes, String argSkypeStatus) 
	{
		this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		this.intervalMinutes=argTimeoutMinutes;
		this.skypeStatus=argSkypeStatus;
	    start();
	}

	
	public void stopTimer()
	{
		this.stopTimer=true;
		this.interrupt();
	}
	
	public void run() 
	{
		try
		{
		  sleep(10*1000);
		  while (!interrupted() && !stopTimer)
		  {	  
			  if (!stopTimer)
				  util.parseSkypeResponse("SET USERSTATUS "+skypeStatus,"USERSTATUS "+skypeStatus);
			  sleep(this.intervalMinutes*60*1000);
		  }
		}
		catch(Exception e)
		{}
	}
}
