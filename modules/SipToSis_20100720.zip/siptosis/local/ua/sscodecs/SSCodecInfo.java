package local.ua.sscodecs;

public class SSCodecInfo
{
	String codecClassName;
	String codecOfficialName;
	int frameSize;
	public double inGain;
	public double outGain;

	SSCodecInfo(String argcodecClassName,String argcodecOfficialName,int argframeSize,double arginGain,double argoutGain)
	{
		codecClassName=argcodecClassName;
		codecOfficialName=argcodecOfficialName;
		frameSize=argframeSize;
		inGain=arginGain;
		outGain=argoutGain;
	}
	
}
