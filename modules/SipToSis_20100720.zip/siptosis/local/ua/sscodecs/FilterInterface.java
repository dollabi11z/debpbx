package local.ua.sscodecs;

public interface FilterInterface
{
	public void filter(byte[] inBuf);
}
