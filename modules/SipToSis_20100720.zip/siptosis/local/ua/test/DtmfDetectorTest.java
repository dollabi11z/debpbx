package local.ua.test;

import java.io.File;
import java.io.PipedOutputStream;
import java.util.Vector;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;

import local.ua.SSInBandDtmfDetector;
import local.ua.SSInBandDtmfInterface;

import org.apache.log4j.PropertyConfigurator;

public class DtmfDetectorTest implements SSInBandDtmfInterface
{
	private static Vector<Integer> foundDigits=new Vector<Integer>();

	public void gotDtmfDigit(int digit)
	{
		foundDigits.add(digit);
	}
	
	private void doTest()
	{
		
				String clipFile;
    	       // clipFile="testingclips/DTMF_tones_8k_16bit.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms_-32db.wav"; // starts to fail at this level
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms_-27db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms_-20db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms_-12db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms_-6db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_40ms.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_70ms.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_100ms_-6db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_100ms.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_200ms_-3db.wav";
		       //clipFile="testingclips/DTMF_tones_16k_16bit_200ms.wav";
			   //clipFile="testingclips/test_pcm_out.wav";
		       //clipFile="testingclips/test_pcm_out_0db.wav";
		       clipFile="testingclips/track05.wav";
	       	   
	       	   int ReadSize=5000;
	       	   
	       	   AudioInputStream audStream=null;
			   try
			   {
		       	    PropertyConfigurator.configure("log.properties");
		       	    
		       	    AudioFormat af=AudioSystem.getAudioFileFormat(new File(clipFile)).getFormat();
		       	    SSInBandDtmfDetector detector=new  SSInBandDtmfDetector(this,(int)af.getSampleRate(),af.getSampleSizeInBits()/8,30,40,1f);
		       	    PipedOutputStream dtmfDectorStream=new PipedOutputStream(detector.getPipedInputStream());
		       	    
		       	     
					System.out.println("clipFormat="+af.toString());
					
					byte data[] = new byte[ReadSize];
					
					audStream=AudioSystem.getAudioInputStream(new File(clipFile));

					 System.out.println("File:"+clipFile+" Opened");
			     
				     while (audStream.available()>=ReadSize)
				     {	   
		
				    	    audStream.read(data,0,ReadSize);
				    	    dtmfDectorStream.write(data,0,ReadSize);
				    	    try {Thread.sleep(1);} catch(Exception se){}
				     }
		    	     dtmfDectorStream.write(new byte[ReadSize],0,ReadSize);
				     dtmfDectorStream.flush();
				     Thread.sleep(20);
				     detector.stopDetecter();
			   }
			   catch (Exception e)
			   {
				   e.printStackTrace();
				   System.err.println("Error - Msg:"+e.getLocalizedMessage());
			   }
	       	   
			   System.out.println("\r\nFound digits: "+foundDigits.toString()+" Count="+foundDigits.size());
			   
			   System.exit(0);
	   }    


	/** for testing. */
	public static void main(String[] args) throws Exception 
	{
		DtmfDetectorTest dt=new DtmfDetectorTest();
		dt.doTest();
	}
		
}
