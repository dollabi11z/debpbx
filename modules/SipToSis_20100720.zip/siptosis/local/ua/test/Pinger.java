package local.ua.test;

import com.skype.Skype;
import com.skype.connector.Connector;

public class Pinger extends Thread 
{
	private boolean stopped=false;
	
	
	public void halt()
	{
		stopped=true;
	}
	
	public void run() 
	{
		while (!stopped)
		{	
			local.ua.util.parseSkypeResponse("PING","PONG");
			try
			{
			  Skype.getVersion();
			}
			catch (Exception e)
			{}
			
			try
			{
				sleep(2);
			}
			catch(Exception e)
			{}
		}
	}
	
}
