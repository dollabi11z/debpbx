/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Based on mjsip 1.6 software and skype4java
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;


import org.zoolu.sip.address.NameAddress;
import org.zoolu.sip.address.SipURL;
import org.zoolu.sip.provider.SipProvider;
import org.zoolu.sip.message.Message;

import com.skype.Call;
import com.skype.Skype;
import com.skype.SkypeException;
import com.skype.Chat;
import com.skype.ContactList;
import com.skype.Friend;
import com.skype.VoiceMail;
import com.skype.VoiceMailListener;
import com.skype.connector.Connector;
import com.skype.connector.ConnectorException;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import org.apache.log4j.Logger;

/* Skype SIP user agent (UA).
 */
public class SSCallChannel extends Thread implements UserAgentListener, RegisterAgentListener, AuthTimerInterface
                                  , SipCallRingTimerInterface, CallTimerInterface,VoiceMailListener
{           

   /** User Agent */
   protected SkypeUserAgent ua;
   
   private SkypeProfile skype_profile;
   
   private boolean skypeCallAudioRedirected=false;
   
   private ControllerChannelInterface controller=null;
   
   private String authPin="";
   private int authFailCnt=0;
   private AuthState callAuthState=AuthState.IDLE;
   private enum AuthState {IDLE,SIP_WAITFORPIN, SIP_WAITFORDESTINATION,SKYPE_WAITFORPIN,SKYPE_WAITFORDESTINATION};
   private AuthTimer authTimer=null;

   private CallTimer callTimer=null;
   
   /** UserAgentProfile */
   private UserAgentProfile user_profile;
         
   private Logger log=null;
   
   private CallHistoryEntry baseCallEntry=new CallHistoryEntry();
   
   private int hangupStatus=403;
   
   private String curSipCallee="";
   private String curSipCallerIP="";
   private boolean doPinCalleeDial=false;
   
   private SipCommandRunner sipCmdRunner=null;
   private SkypeCommandRunner skypeCmdRunner=null;
   private SipCallRingTimer sipCallRingTimer=null;
   private SkypeRinger skypeRinger=null;
   
   private boolean locked=true;
   
   private String glbSkypeCallCurrency="";
   private Vector<String> glbPossibleRunaway=new Vector<String>();

   
   private long callStart=0;
   private long lastSipCallAttempt=0;
   private String joinSkypeUserId=null;
   private boolean earlySkypeAnswered=false;
   private boolean conferenceCall=false;
   protected Vector<SkypeChannel> skypeChannels=new Vector<SkypeChannel>();
   private Hashtable<String,CallHistoryEntry> skypeCallTracker=new Hashtable<String,CallHistoryEntry>();
   private SkypeVMChannel vmGreeting=null;
   private SkypeVMChannel vmOutgoing=null;
   private boolean vmDelayedMode=false; // flag to indicate wacky 4.x client outgoing voicemail
   private boolean hangupPending=false;
   private boolean vmGreetingStarted=false;
   
   
   private boolean possibleVoiceMail=false;
   
   private CallBackHandler callBackHandler=null;
   private Vector<String> callBackTargets=null;
   private boolean callBack=false;
   private boolean callBackTwoStageDialing=false;
   private VoiceMailPlayer voiceMailPlayer=null;
   
   private static final boolean debugRate=false; // leave false under normal conditions
   
   private int lastCallFailureResponse=-1;
   private Thread waitRingClear = null;
   
   /** Costructs a CallChannel */
   public SSCallChannel(SipProvider sip_provider, UserAgentProfile user_profile,SkypeProfile skype_profile,int argRtpPort,int argSkypePort,ControllerChannelInterface argCI,int chanId) throws Exception
   {  
	  this.setName(this.getClass().getName()+".#C"+chanId);
	  this.log = Logger.getLogger(this.getName());
	  this.controller=argCI;
	  this.skype_profile=skype_profile;
      this.user_profile=user_profile;
      this.ua=new SkypeUserAgent(sip_provider,user_profile,this,skype_profile,argRtpPort,argSkypePort,chanId);      
      this.hangupStatus=skype_profile.baseFailureResponse;
      
      if (debugRate)
    	  log.info("###################### debugRate is on ###################");
      start();
   }
   
   /** Makes a new sip call */
   public void call(String target_url)
   {  
	   baseCallEntry.callTo=target_url.toString();

	  lock();
	  ua.hangup();
      log.info("UAC: CALLING "+target_url.replaceAll(";.*",""));
      if (!ua.user_profile.audio && !ua.user_profile.video) log.info("ONLY SIGNALING, NO MEDIA");
      ua.call(target_url);       
   } 
         
         
   /** Receives incoming calls (auto accept) */
   public void listen()
   {  
	  
	  if (callBackHandler!=null) // callbackHandler not finished
		  return;
	  
	  
	  logCall(); 
	  curSipCallee="";
	  curSipCallerIP="";
	  doPinCalleeDial=false;
	  joinSkypeUserId=null;
	  earlySkypeAnswered=false;
	  callBackTargets=null;
	  callBack=false;
	  callBackTwoStageDialing=false;

	  clearVoiceMailPlayer();
	  
	  clearCallTimer();
	  
	  clearAuthTimer();

	  clearSipCommandRunner();

	  clearSkypeCommandRunner();
	  
	  clearSipCallRingTimer();
	  
	  clearSkypeRinger();
	  
	  callAuthState=AuthState.IDLE;
	  

   	  ua.hangup(hangupStatus);
   	  
	  if (vmDelayedMode)
	  {
		  log.info("Delaying Hangup For Voicemail");
		  hangupPending=true;
		  if (vmGreeting!=null)
			  vmGreeting.cancel();
		  if ( vmOutgoing!=null)
		     vmOutgoing.cancel();
		  return;
	  }
	  
	  hangupPending=false;

	  if (vmGreeting!=null || vmOutgoing!=null)
	  {	  
		  log.info("Shutdown Voicemail");
		  closeVMGreeting();
		  closeVMOutgoing();
		  try{Skype.removeVoiceMailListener(this);}catch(Exception e){}
	  }
   	  
	  vmGreetingStarted=false;
	  
      if (skypeChannels.size()==1 && (skype_profile.skypeInboundSipDestUnavailableAction.equals("ring") || lastCallFailureResponse==606))
      {	  
    	 Call curCall=null;
    	 try
    	 {
    		 SkypeChannel curChannel=skypeChannels.get(0);
    		 curCall=curChannel.getSkypeCall();
    		 Call.Type ct=curCall.getType();
	         if (curCall.getStatus()==Call.Status.RINGING && (ct==Call.Type.INCOMING_P2P || ct==Call.Type.INCOMING_PSTN))
	         {	 
	        	  if (lastCallFailureResponse==606)
	        	  {
	        		   if (waitRingClear!=null)
	        			   return;
	        		   
					   final SSCallChannel cc=this;
					   final Call skypeCall=curCall;
					   waitRingClear = new Thread (new Runnable() 
					   {
						   public void run() 
						   {
							   try
							   {
							     while (skypeCall.getStatus()==Call.Status.RINGING)
							     {
								   sleep(100);
							     }
							   }
							   catch(Exception e)
							   {}
							   cc.listen();
						   }
		               }, "Wait ring cleared");
					   waitRingClear.setDaemon(true);
					   waitRingClear.start();
			    	   log.info("Waiting for incoming Skype call to clear.");
					   
	        		   return;
	        	  }
	        	 
		    	  log.info("Allowing Skype Client to ring.");
		    	  this.removeChannel(curChannel);
	         }
    	 }
    	 catch(Exception e)
    	 {log.debug("error",e);}
   	     curCall=null;
      }
    	  
      waitRingClear=null;
      lastCallFailureResponse=-1;
      
   	  cancelSkypeCall();

      
      hangupStatus=skype_profile.baseFailureResponse;

      ua.listen(); 

      if (this.locked)
      {  
		  java.lang.Runtime runtime=java.lang.Runtime.getRuntime();
		  if (log.isDebugEnabled())
			  log.debug("TotMem="+(runtime.totalMemory() / 1024 )+"KB  Free="+(runtime.freeMemory() / 1024 )+"KB");
	      runtime.gc(); 
		  if (log.isDebugEnabled())
			  log.debug("TotMem="+(runtime.totalMemory() / 1024 )+"KB  Free="+(runtime.freeMemory() / 1024 )+"KB");
      }
      
      unLock();
      
      if (!ua.user_profile.audio && !ua.user_profile.video) log.info("ONLY SIGNALING, NO MEDIA");       
   } 


   /** Starts the UA */
   public void run()
   {
      try
      {  // Set the re-invite
         if (user_profile.re_invite_time>0)
         {  ua.reInvite(user_profile.contact_url,user_profile.re_invite_time);
         }

         // Set the transfer (REFER)
         if (user_profile.transfer_to!=null && user_profile.transfer_time>0)
         {  ua.callTransfer(user_profile.transfer_to,user_profile.transfer_time);
         }

          // UAS
          if (user_profile.accept_time>=0) 
           	log.info("UAS: AUTO ACCEPT MODE");
          listen();
         
      }
      catch (Exception e)  {  log.fatal("error",e); System.exit(SkypeUA.ExitCode.FATALERROR.code());  }

   
   }

   // ******************* UserAgent callback functions ******************

   /** When a new sip call is incoming */
   public void onUaCallIncoming(UserAgent tua, NameAddress callee, NameAddress caller,Message invite)
   {  
	     lock();
	     log.info("incoming sip call from "+caller.toString()+" callee="+callee.toString());
	     lastSipCallAttempt=System.currentTimeMillis();
	     baseCallEntry.callFrom=caller.toString();
    	 
    	 //SessionDescriptor remote_sdp=new SessionDescriptor(tua.call.getRemoteSessionDescriptor());
    	 //curSipCallerIP=(new Parser(remote_sdp.getConnection().toString())).skipString().skipString().getString();
    	 curSipCallerIP=invite.getRemoteAddress();
         curSipCallee=callee.toString();
	     handleSipCall(caller.toString(),curSipCallerIP,callee.toString());
   }
   
   /** When an incoming call has been confirmed */
   public void onUaCallConfirmed(UserAgent ua)
   {
	   		if (ua.onRemoteSipHold)
	   		{	
				log.info("Call Holding");
	   			return;
	   		}
	   		
	   		if (this.ua.skypeHoldingLocal && !this.ua.onRemoteSipHold)
	   		{	
	   			resumeSkypeCall();
				log.info("Call Resuming");
	   			return;
	   		}	
	   		
	   		clearSkypeRinger();
			
	   		log.info("CallConfirmed Active");
	   		
			if (sipCmdRunner!=null)
				sipCmdRunner.start();
			
			startCallTime();
   }
   
   /** When an outgoing sip call is remotly ringing */
   public void onUaCallRinging(UserAgent tua)
   {  
	   log.debug("onUaCallRinging");
	   if (skype_profile.sendRingToSkypeCaller && callBackTargets==null)
	   {
		   log.debug("onUaCallRinging - send ring to skype user");
		   earlySkypeAnswered=true;
		   if (skypeAnswer()) // make sure skype caller has been answered
		   {
			   if (skypeRinger==null)
				   skypeRinger=new SkypeRinger(skype_profile.skypeRingInterval,this,skype_profile.skypeRingFile);
	   	   }
		   else
			   this.listen();
	   }
   }

   /** When an outgoing sip call is remotly ringing */
   public void onUaSessionProgress(UserAgent tua)
   {  
	   log.debug("onUaSessionProgress");
	   
	   if (skype_profile.handleSipEarlyMedia)
	   {
		   clearSkypeRinger();
		   earlySkypeAnswered=true;
		   if (skypeAnswer()) // make sure skype caller has been answered
		   {	   
			  log.info("Sending SIP Early Media to Skype");
			  this.ua.launchMediaApplication();
		   }
		   else
			   this.listen();
	   }
	   else if (skype_profile.sendRingToSkypeCaller)
	   {	   
		   log.debug("onUaSessionProgress - send ring to skype user");
		   earlySkypeAnswered=true;
		   if (skypeAnswer()) // make sure skype caller has been answered
		   {
			   if (skypeRinger==null)
				   skypeRinger=new SkypeRinger(skype_profile.skypeRingInterval,this,skype_profile.skypeRingFile);
		   }
		   else
			   this.listen();

	   }	   
   }

   
   /** When an outgoing sip call has been accepted */
   public void onUaCallAccepted(UserAgent tua)
   {
	   log.debug("onUaCallAccepted");
  	   clearSkypeRinger();
	   if (joinSkypeUserId!=null)
	   {
		 if (this.makeSkypeCall(joinSkypeUserId))
		 {	 
			 this.ua.queueSipClip(skype_profile.dialingFile);
		 }
		 else
		 {	 
			 log.error("Skype called Failed.");
			 this.ua.queueSipClip(skype_profile.invalidDestFile); 
			 this.listen();
		 }
	   }
	   else if (callBackTargets!=null)
	   {
		   // if single target callback, switch to IVR mode
		   if (this.callBackTargets.size()==1)
		   {
			      callBackTargets=null; // out of callback mode
				  callAuthState=AuthState.SIP_WAITFORDESTINATION;
				  log.info("CallBack: SIP Connected");
				  this.ua.queueSipClip(skype_profile.destinationFile);
				  startAuthTimer(skype_profile.destinationTimeout);
		   }
	   }
	   else
	   {   
	     if (skypeAnswer())
	    	 startCallTime();
	     else
			 this.listen();
	   }
	   
   }
   
   /** When a call has been trasferred */
   public void onUaCallTrasferred(UserAgent tua)
   {  
   }

   /** When an incoming sip call has been cancelled */
   public void onUaCallCancelled(UserAgent tua)
   {  
	   log.debug("onUaCallCancelled");
	   listen();
   }

   /** When an ougoing sip call has been refused or timeout */
   public void onUaCallFailed(UserAgent tua)
   {  
	   lastCallFailureResponse=tua.getLastFailureCode();
	   log.debug("onUaCallFailed");
   	   listen();
   }

   /** When a sip call has been locally or remotely closed */
   public void onUaCallClosed(UserAgent tua)
   {  
	   log.debug("onUaCallClosed");
	   
       this.ua.stopMedia();
	   if (skypeChannels.size()>=2) // leave the call active since there are at least two calls still in progress
			return;

       listen();   
       
   }
   
   // dtmf received
   public void onDtmfReceived(UserAgent tua,int digit,boolean isSkype)
   {
	   //log.debug("onDtmfReceived digit:"+digit+" sipDtmfBuffer="+ua.getDtmfBuffer()+" skypeDtmfBuf:"+ua.getSkypeDtmfBuffer());
	   log.debug("onDtmfReceived digit: "+digit);
	   if (!isSkype)
	   {
		   if (callAuthState==AuthState.SIP_WAITFORPIN)
		   {
	
			   if (tua.getDtmfBuffer().startsWith(authPin))
			  {
				  // got auth pin, send dest prompt and wait for dest entry
				  authFailCnt=0;
				  clearAuthTimer();
				  
				  if (doPinCalleeDial)
				  {
					  callAuthState=AuthState.IDLE;
					  String skypeDest=curSipCallee.replaceAll("(?i).*sip:<?([^@<]+)@.*", "$1");
					  if (directSkypeDial(skypeDest))
						  this.ua.queueSipClip(skype_profile.dialingFile); // would be nicer if we sent ring to sip device

				  }
				  else
				  {	  
					  callAuthState=AuthState.SIP_WAITFORDESTINATION;
					  log.info("Pin Authorized");
					  tua.chopDtmfBuffer(authPin.length());
					  this.ua.queueSipClip(skype_profile.destinationFile);
					  startAuthTimer(skype_profile.destinationTimeout);
				  }
			  }
		   }
		   else if (callAuthState==AuthState.SIP_WAITFORDESTINATION)
		   {
			   if (tua.getDtmfBuffer().indexOf("#")>=0)
			   {
				   // got end of dest entry, send dialing sound, make the skype call
				   authFailCnt=0;
				   clearAuthTimer();
				   callAuthState=AuthState.IDLE;
				   String skypeDest=ua.getDtmfBuffer().replaceAll("#.*$", "").trim();
				   this.ua.clearDtmfBuffer();
				   if (skypeDest.length()>0)
				   {	   
					   // make the skype Call
					   log.info("Dialing Destination:"+skypeDest);
					   if (!makeSkypeCall(skypeDest))
					   {
						   log.info("Skype Call Failed");
						   callAuthState=AuthState.SIP_WAITFORDESTINATION;
						   this.ua.queueSipClip(skype_profile.invalidDestFile); 
						   this.ua.queueSipClip(skype_profile.destinationFile);
						   startAuthTimer(skype_profile.destinationTimeout);
					   }
					   else
						   this.ua.queueSipClip(skype_profile.dialingFile); // would be nicer if we sent ring to sip device
							   
				   }
				   else
				   {
					   callAuthState=AuthState.SIP_WAITFORDESTINATION;
					   this.ua.queueSipClip(skype_profile.destinationFile);
					   startAuthTimer(skype_profile.destinationTimeout);
				   }
			   }
		   }
		   else if (skypeChannels.size()>0 && !this.ua.skypeHoldingLocal)
		   {
			   if (this.skype_profile.sendSipDtmfToSkype)
			   {
				   int fixDigit=digit;
				   if (digit==10)
					   fixDigit=Call.DTMF.TYPE_ASTERISK.ordinal();
				   else if (digit==11)
						fixDigit=Call.DTMF.TYPE_SHARP.ordinal();

				   for (int c=0;c<skypeChannels.size();c++)
				   {
					   Call curCall=skypeChannels.get(c).getSkypeCall();
					   Call.Status callStat=null;
					   try
					   {
						   callStat=curCall.getStatus();
						   if (callStat==Call.Status.INPROGRESS || callStat==Call.Status.EARLYMEDIA) 
						   {	   
							
							   if (fixDigit<=11)
							   {	   
								 curCall.send(Call.DTMF.values()[fixDigit]);
							     log.debug("DTMF:"+digit+" sent to skype");
							   }						   }   
					   }
					   catch (Exception e)
					   {
						   if (callStat==Call.Status.EARLYMEDIA)
							     log.error("Error sending dtmf: "+digit+" to skype during early media state");
						   else
						     log.error("Error sending dtmf: "+digit+" to skype: ",e);
					   }
				   }
			   }
		   }
		   else if (callAuthState==AuthState.IDLE)
		   {
			   if (voiceMailPlayer!=null)
			   {
				   // send digit in a new thread to it doesn't block
				   final int sendDigit=digit;
				   Thread event = new Thread (new Runnable() {
					   public void run() {
						   voiceMailPlayer.gotDtmf(sendDigit);
					   }
	                }, "VMP DTMF Event");
	                event.setDaemon(true);
	                event.start();
				   
			   }	   
		   }
	   }
	   else
	   {	   
		   if (callAuthState==AuthState.SKYPE_WAITFORPIN)
		   {
			   
			  if (this.ua.getSkypeDtmfBuffer().startsWith(authPin))
			  {
				  // got auth pin, send dest prompt and wait for dest entry
				  authFailCnt=0;
				  clearAuthTimer();
				  callAuthState=AuthState.SKYPE_WAITFORDESTINATION;
				  log.info("Pin Authorized");
				  this.ua.chopSkypeDtmfBuffer(authPin.length());
				  this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
				  startAuthTimer(skype_profile.destinationTimeout);
			  }
		   }
		   else if (callAuthState==AuthState.SKYPE_WAITFORDESTINATION)
		   {
			   if (this.ua.getSkypeDtmfBuffer().indexOf("#")>=0)
			   {
				   authFailCnt=0;
				   clearAuthTimer();
				   callAuthState=AuthState.IDLE;
				   String sipDest=ua.getSkypeDtmfBuffer().replaceAll("#.*$", "").trim();
				   this.ua.clearSkypeDtmfBuffer();

				   if (callBack)
				   {
					   if (sipDest.startsWith(skype_profile.callBackForceSipPrefix))
					   {	   
						   sipDest=sipDest.substring(1); // do sip
					   }	   
					   else
					   {
						   if (sipDest.length()>0)
						   {	 
							   callBackTwoStageDialing=true;
							   // add a skype call to this one (conference)
							   this.ua.queueSkypeClip(skype_profile.skypeDialingFile); // would be nicer if we sent ring to skype
							   this.waitForSkypeClipsComplete();
							   // make the skype Call
							   log.info("Dialing Skype Destination:"+sipDest);
							   if (!makeSkypeCall(sipDest))
							   {
								   log.info("Skype Call Failed");
								   callAuthState=AuthState.SIP_WAITFORDESTINATION;
								   this.ua.queueSkypeClip(skype_profile.invalidDestFile); 
								   this.ua.queueSkypeClip(skype_profile.destinationFile);
								   startAuthTimer(skype_profile.destinationTimeout);
							   }
							   else
								   this.ua.queueSipClip(skype_profile.dialingFile); // would be nicer if we sent ring to sip device
						   }
						   else
						   {
							   callAuthState=AuthState.SKYPE_WAITFORDESTINATION;
							   this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
							   startAuthTimer(skype_profile.destinationTimeout);
						   }
						   return;
					   }
				   }
				   
				   // got end of dest entry, send dialing sound, make the sip call
				   sipDest=this.controller.getAuthMap().sipOutFilter(sipDest);
				   if (sipDest.length()>0)
				   {
					   log.info("Dialing Sip Destination:"+sipDest);
					   this.ua.queueSkypeClip(skype_profile.skypeDialingFile); // would be nicer if we sent ring to skype
					   this.waitForSkypeClipsComplete();

					   // set the skype id
					   try
					   {
						 NameAddress tmpfrom;
						 String skypeid=skypeChannels.get(0).getSkypeCall().getPartnerId();	
						 if (skype_profile.replaceFromWithSkypeId)
						 {
							 String skypeFullName=skypeChannels.get(0).getSkypeCall().getPartnerDisplayName();	
							 if (skypeFullName==null)
								 skypeFullName=skypeid;
							 else
							 {
								 skypeFullName=skypeFullName.replaceAll("[^0-9A-Za-z ]","");
								 if (skypeFullName.length()<1)
									 skypeFullName=skypeid;
							 }

							 SipURL tmpurl=new SipURL(ua.user_profile.contact_url);
					    	 tmpfrom=new NameAddress(skypeFullName,new SipURL(skypeid,tmpurl.getHost(),tmpurl.getPort()));
						 }
						 else
							 tmpfrom=new NameAddress(skypeid,new SipURL(ua.user_profile.contact_url));
					     
					     ua.user_profile.from_url=tmpfrom.toString();
					   }
					   catch (Exception e)
					   {
					     log.error("Error",e);
					     listen();
					     return;
					   }

					   // make the sip Call
					   this.call(sipDest);
				   }
				   else
				   {
					   callAuthState=AuthState.SKYPE_WAITFORDESTINATION;
					   this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
					   startAuthTimer(skype_profile.destinationTimeout);
				   }
			   }
		   }
		   else if (this.ua.call_state!=UserAgent.UA_IDLE && !this.ua.onLocalSipHold)
		   {
			   if (this.skype_profile.sendSkypeDtmfToSip)
			   {	
					   this.ua.queueSipDtmfDigits(this.ua.dtmfConvertToString(digit));
					   log.debug("DTMF:"+digit+" sent to sip");
			   }
		   }
		   else if (callAuthState==AuthState.IDLE)
		   {
			   //log.debug("Auth State not handled:"+callAuthState);
		   }	   
	   }
   }
   
   // AuthTimerInterface callback
   public void onAuthTimeout()
   {
	   authTimer=null;
	   if (callAuthState==AuthState.IDLE)
		   return;
	   
	   authFailCnt++;
	   switch (callAuthState)
	   {
	   	   case SIP_WAITFORPIN:
			   log.info("Pin timeout");
			   if (this.ua.getDtmfBuffer().length()>0 && authFailCnt<skype_profile.pinRetryLimit) // they tried, so restart
			   {
				   this.ua.queueSipClip(skype_profile.invalidPinFile); 
				   this.ua.clearDtmfBuffer();
				   this.ua.queueSipClip(skype_profile.pinFile);
				   startAuthTimer(skype_profile.pinTimeout);
			   }
			   else
			   {	   
				   this.ua.queueSipClip(skype_profile.invalidPinFile);
				   waitForSipClipsComplete();
				   listen();
			   }
			   break;
	   	   case SIP_WAITFORDESTINATION:
			   log.info("Destination timeout");
			   if (this.ua.getDtmfBuffer().length()>0 && authFailCnt<skype_profile.destRetryLimit) // they tried, so restart
			   {
				   this.ua.queueSipClip(skype_profile.invalidDestFile); 
				   this.ua.clearDtmfBuffer();
				   this.ua.queueSipClip(skype_profile.destinationFile);
				   startAuthTimer(skype_profile.destinationTimeout);
			   }
			   else
			   {	   
				   this.ua.queueSipClip(skype_profile.invalidDestFile); 
				   waitForSipClipsComplete();
				   listen();
			   }
		       break;
	   	   case SKYPE_WAITFORPIN:
			   log.info("Pin timeout");
			   if (this.ua.getSkypeDtmfBuffer().length()>0 && authFailCnt<skype_profile.pinRetryLimit) // they tried, so restart
			   {
				   this.ua.queueSkypeClip(skype_profile.skypeInvalidPinFile); 
				   this.ua.clearSkypeDtmfBuffer();
				   this.ua.queueSkypeClip(skype_profile.skypePinFile);
				   startAuthTimer(skype_profile.pinTimeout);
			   }
			   else
			   {	   
				   this.ua.queueSkypeClip(skype_profile.skypeInvalidPinFile);
				   waitForSkypeClipsComplete();
				   cancelSkypeCall();
				   unLock();
			   }
		       break;
	       case SKYPE_WAITFORDESTINATION:
			   log.info("Destination timeout");
			   if (this.ua.getSkypeDtmfBuffer().length()>0 && authFailCnt<skype_profile.destRetryLimit) // they tried, so restart
			   {
				   this.ua.queueSkypeClip(skype_profile.skypeInvalidDestFile); 
				   this.ua.clearSkypeDtmfBuffer();
				   this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
				   startAuthTimer(skype_profile.destinationTimeout);
			   }
			   else
			   {	   
				   this.ua.queueSkypeClip(skype_profile.skypeInvalidDestFile); // hangup after
				   waitForSkypeClipsComplete();
				   cancelSkypeCall();
				   unLock();
			   }	   
		       break;
		   default:
			   cancelSkypeCall();
			   listen();
		       break;
	   }
		
   }

   public void startSipAuthSequence(String argPin)
   {
	    authPin=argPin;
	  
	    //log.info("Pin="+authPin);
		   
	    if (authPin.trim().length()==0)
		   this.ua.queueSipClip(skype_profile.destinationFile);
	    else
		   this.ua.queueSipClip(skype_profile.pinFile);
	   
		authFailCnt=0;
		if (authPin.trim().length()==0)
	    {	   
		   callAuthState=AuthState.SIP_WAITFORDESTINATION;
		   authTimer=new AuthTimer(skype_profile.destinationTimeout,this);
		   authTimer.start();
	    }
	    else
	    {
		   callAuthState=AuthState.SIP_WAITFORPIN;
		   authTimer=new AuthTimer(skype_profile.pinTimeout,this);
		   authTimer.start();
	    }
   }
   
   public void startSkypeAuthSequence(String argPin)
   {
	    authPin=argPin;
	  
	    //log.info("Pin="+authPin);
		   
	    if (authPin.trim().length()==0)
		   this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
	    else
		   this.ua.queueSkypeClip(skype_profile.skypePinFile);
	   
		authFailCnt=0;
	    if (authPin.trim().length()==0)
	    {	   
		   callAuthState=AuthState.SKYPE_WAITFORDESTINATION;
		   authTimer=new AuthTimer(skype_profile.destinationTimeout,this);
		   authTimer.start();
	    }
	    else
	    {
		   callAuthState=AuthState.SKYPE_WAITFORPIN;
		   authTimer=new AuthTimer(skype_profile.pinTimeout,this);
		   authTimer.start();
	    }
   }

   private synchronized void clearAuthTimer()
   {
	   if (authTimer!=null)
		   authTimer.stopTimer();
	   authTimer=null;
   }
   
   private void startAuthTimer(int timeout)
   {
		  authTimer=new AuthTimer(timeout,this);
		  authTimer.start();
   }
   
   public synchronized void clearSipCommandRunner()
   {
	   if (sipCmdRunner!=null)
		   sipCmdRunner.stopCommands();
	   sipCmdRunner=null;
   }

   public synchronized void clearSkypeCommandRunner()
   {
	   if (skypeCmdRunner!=null)
		   skypeCmdRunner.stopCommands();
	   skypeCmdRunner=null;
   }

   // **************** RegisterAgent callback functions *****************

   /** When a UA has been successfully (un)registered. */
   public void onUaRegistrationSuccess(RegisterAgent ra, NameAddress target, NameAddress contact, String result)
   {  log.info("Registration success: "+result);
   }

   /** When a UA failed on (un)registering. */
   public void onUaRegistrationFailure(RegisterAgent ra, NameAddress target, NameAddress contact, String result)
   {  log.info("Registration failure: "+result);
   }
   

	private void handleSipCall(String callerSipCID,String sipCIP, String argdestination)
	{
		// argdestination = <sip:66@192.168.0.4:5070>
		String destination=this.controller.getAuthMap().getSkypeDest(callerSipCID, sipCIP, argdestination);
		
		log.debug("handleSipCall - authMap:"+destination);

		if (destination==null || destination.length()==0)
		{
			  log.info("handleSipCall - rejected call (no auth/destination)");
	          listen();
	          return;
		}
		else if (destination.toLowerCase().startsWith("callback:"))
		{	
			startCallBack(destination,true);
		}
		else if (destination.indexOf(":")<0)
		{
			directSkypeDial(destination);
		}
		else
		{
			log.info("handleSipCall - Command List:"+destination);
		    if (ua.call_state==UserAgent.UA_INCOMING_CALL)
			   ua.accept();
			
			sipCmdRunner=new SipCommandRunner(destination,this);
		}
		
	}
	
	private boolean directSkypeDial(String destination)
	{
		log.info("Skype Dial:"+destination);
		if (!makeSkypeCall(destination))
		{
	          listen();
	          return false;
		}		
		return true;
	}
	
	/* when skype call status changes */
	public void callStatusChanged(SkypeChannel skypeChannel,Call.Status status) throws SkypeException
	{
		Call curCall=skypeChannel.getSkypeCall();
		String curCallId=curCall.getId();
		
		switch (status)
		{
		    case FINISHED:
		    	   skypeCallAudioRedirected=false;
			       if (vmGreeting!=null || vmOutgoing!=null)
			       {
			    	    log.info("VoiceMail In Progress");
						// voicemail in progress - wait it out
			    	    break;		
			       }
				   else if (possibleVoiceMail)
				   {
					  //wait up to 1 second for a possible voicemail (windows 4.x)
					  int cnt=0;
					  while (cnt++<10 && vmGreeting==null && vmOutgoing==null)
					  {	  
				        try {sleep(100);} catch (Exception e) {} 
					  }
					  
				      if (vmGreeting!=null || vmOutgoing!=null)
				      {
				    	  vmDelayedMode=true;
						  log.info("Buggy VoiceMail Started");
				          // voicemail started - don't hangup (win 4.x)
				    	  break;
				      }
				   }  
			       // do not add a break here - let it drop into call close process
		    case CANCELLED:
		    case MISSED:
		    case REFUSED:
		    case FAILED:
		    case BUSY:  
					// tear down the call
		    	    String msg="skypeCallStatus["+curCallId+"] - Complete: "+status;
		    	    if (status==Call.Status.FAILED)
		    	    {
		    	      try
		    	      {
		    	         msg+=" (Reason: "+util.convertCallFailureCode(curCall.getErrorCode())+")";
		    	      }
		    	      catch (Exception e)
		    	      {
		    	    	  msg+=" (Reason: Unknown)";
		    	    	  log.debug("Error retrieving failure reason",e);
		    	      }
		    	    }
		    	    
					log.info(msg);
					if (curCall!=null)
					{	
						removeChannel(skypeChannel);
						
						int actCallCount=skypeChannels.size();
						if (ua.call_state==UserAgent.UA_ONCALL)
							actCallCount++;
						
						if (actCallCount>=2) // leave the call active since there are at least two calls in progress
						{
							return;
						}
						
						cancelSkypeCall();
					}
					this.ua.stopMedia();
		
					hangupStatus=skype_profile.baseFailureResponse;
					if (status==Call.Status.REFUSED)
						hangupStatus=skype_profile.skypeRefusedResponse;
					else if (status==Call.Status.FAILED) // when invalid user (possibly no skype credit) or something else
					{
						if (msg.toLowerCase().contains("does not exist"))
							hangupStatus=skype_profile.skypeInvalidDestinationResponse;
						else
							hangupStatus=skype_profile.skypeFailedResponse;
					}	
					else if (status==Call.Status.BUSY)
						hangupStatus=skype_profile.skypeBusyResponse;
					
					listen();
					
			        break;
		    case EARLYMEDIA:   
				if (skype_profile.handleSkypeEarlyMedia)
				{
					// skypeout earlymedia handling
					try
					{
						// start skype media and accept the sip call
						log.info("skypeCallStatus["+curCallId+"] - "+status);
						if (ua.call_state==UserAgent.UA_INCOMING_CALL)
						{
							if (skype_profile.sendSkypeEarlyMediaOverSipSessionProgress)
								ua.sendEarlyMedia();
							else	
								ua.accept();
						}	
						this.redirSkypeCallAudio();
						this.ua.startSkypeMedia(skype_profile.sendSkypeEarlyMediaOverSipSessionProgress);  
					}
					catch(Exception e)
					{
						
						log.error("skypeCallStatus["+curCallId+"] error",e);
						cancelSkypeCall();
						listen();
					}
					   
				}
				break;
		    case INPROGRESS:
		    	    log.info("skypeCallStatus["+curCallId+"] - "+status);
		    	    possibleVoiceMail=false; // Can't be a VoiceMail
		    	    
		    	    CallHistoryEntry callEntry=new CallHistoryEntry(baseCallEntry);
					callEntry.skypeTemporaryCallid=curCall.getId();
					try
					{
						callEntry.callType=curCall.getType();
						if (callEntry.callType==Call.Type.OUTGOING_P2P || callEntry.callType==Call.Type.OUTGOING_PSTN)
							callEntry.callTo=curCall.getPartnerId(); // fix to
						else if (callEntry.callType==Call.Type.INCOMING_P2P || callEntry.callType==Call.Type.INCOMING_PSTN)
							callEntry.callFrom=curCall.getPartnerId(); // fix from for those doing strange things with forwarding
							
		
						if (ua.call_state==UserAgent.UA_OUTGOING_CALL && (callEntry.callType==Call.Type.INCOMING_P2P || callEntry.callType==Call.Type.INCOMING_PSTN) && !earlySkypeAnswered)
						{ 
								log.info("Incoming Skype Call Manually Answered.");
								removeChannel(skypeChannel);
								curCall=null;
								listen(); // this will stop the sip outbound call
								return;
						}
					
						// start skype media and accept the sip call
				        getSkypeCallRate(callEntry);
						if (ua.call_state==UserAgent.UA_INCOMING_CALL)
						   ua.accept();
						
						this.redirSkypeCallAudio();
						this.ua.startSkypeMedia(false);
		
						//will be done when logged callEntry.callId=Long.toString((curCall.getStartTime().getTime()/1000));
						callEntry.startTime=new Date();
						
						startCallTime();
						
						this.ua.skypeHoldingLocal=false;
						this.ua.skypeHoldingRemote=false;
					}
					catch(Exception e)
					{
						log.error("error",e);
						cancelSkypeCall();
						listen();
					}
		
					skypeCallTracker.put(curCall.getId(),callEntry);
					
					
					// if callback mode and single target, switch to two stage dialing
					if (callBackTargets!=null && callBackTargets.size()==1)
					{
						  callBackTargets=null; // out of callback mode
						  callAuthState=AuthState.SKYPE_WAITFORDESTINATION;
						  log.info("CallBack: Skype Connected");
						  this.ua.queueSkypeClip(skype_profile.skypeDestinationFile);
						  startAuthTimer(skype_profile.destinationTimeout);
					}
		
					if (callBackTwoStageDialing)
					{
						String primaryId=skypeChannels.get(0).getSkypeCall().getId();
						if (skypeChannels.size()>1 && !curCallId.equals(primaryId))
						{
							log.info("Attemping Conference Link");
							String confSetup="SET CALL "+curCall.getId()+" JOIN_CONFERENCE "+primaryId;
							log.debug("confSetup: "+confSetup);
							String callConfResp=util.parseSkypeResponse(confSetup,"CALL");
							log.debug("CallConf: "+callConfResp);
							if (callConfResp.contains("CONF_ID"))
								log.info("Conference Link Successful");
						}
		
					}	
		
					if (this.skypeCmdRunner!=null)
						this.skypeCmdRunner.start();
					
				    break;
		        case LOCALHOLD:  
					log.info("skypeCallStatus["+curCallId+"] - "+status);
					this.ua.skypeHoldingLocal=true;
					break;
		        case REMOTEHOLD:
					log.info("skypeCallStatus"+curCallId+" - "+status);
					this.ua.skypeHoldingRemote=true;
				    break;
		        case ROUTING:
		        case RINGING:
					log.info("skypeCallStatus["+curCallId+"] - "+status);
		        	possibleVoiceMail=true; // Can be a VoiceMail
					// let's redir the audio asap
		        	// let's not redirSkypeCallAudio();
				    break;	
		        case VM_SENT:
		    	    possibleVoiceMail=false;
					log.info("skypeCallStatus["+curCallId+"] - "+status);
		    	    listen();
		        	break;
		        case VM_PLAYING_GREETING:
		        case VM_RECORDING:
				default:
					log.info("skypeCallStatus["+curCallId+"] - "+status);
				    break;
		}
	}
	
	private void removeChannel(SkypeChannel skypeChannel)
	{
		skypeChannel.removeListener();
		synchronized (skypeChannels)
		{
			for (int c=0;c<skypeChannels.size();c++)
			{
				if (skypeChannels.get(c).getSkypeCall().getId().equals(skypeChannel.getSkypeCall().getId()))
				{
					skypeChannels.remove(c);
				    return;
				}
			}
		}
	}
	
	boolean makeSkypeCall(String dest)
	{
		boolean retvar=false;
		boolean retry=true;
		
		if (!skype_profile.skypeClientSupportsMultiCalls)
		{	
			try
			{
				controller.holdOtherSkypeCalls(null);
			}
			catch (Exception e)
			{
				log.error("makeSkypeCall: holdOtherSkypeCalls failed. ",e);
			    return false;
			}
		}		
		
		// filter possible multiple targets
		String filteredDest="";
		String[] targets=dest.split(",");
		for (int x=0;x<targets.length;x++)
		{
		   if (filteredDest.length()>0)
			  filteredDest+=",";
		   filteredDest+=this.controller.getAuthMap().skypeOutFilter(targets[x]);
		}
		
		
		if (!filteredDest.equals(dest))
		{
			dest=filteredDest;
			log.info("Actual destination:"+dest);
		}
		
		if (dest.length()<1)
		{
			log.error("makeSkypeCall: invalid destination");
			return false;
		}
		
		if (dest.toLowerCase().startsWith("callback:"))
		{
			startCallBack(dest,true);
			return true;
		}
		else if (dest.toLowerCase().startsWith("voicemail"))
		{
			return startVoiceMailPlayer();
		}
		
		if (isOverUsageLimit(dest))
		{
			this.hangupStatus=skype_profile.overUsageLimitSipResponse;
			log.info("Call rejected - Usage Limit Reached");
			this.listen();
			return false;
		}
		
		if (dest.split(",").length>1)
		{	
			conferenceCall=true;
			log.debug("making conference call");
		}
		else
			conferenceCall=false;

		
		while (retry)
		{	
			try
			{
				Skype.getVersion(); // test connection now
				
				if (skype_profile.autoAddContactCalledUsers)
					addContacts(dest);
				
				if (skype_profile.sendSkypeIM && (callBackTargets==null || callBackTargets.size()>1))
					sendSkypeIM(dest);
				
				baseCallEntry.callTo=dest;
				addCurrentSkypeCall(Skype.call(dest));
		        retvar=true;
		        break;
			}
			catch(com.skype.NotAttachedException e)
			{
				retry=this.controller.lostSkypeConnection();
				if (!retry) 
				{	
					this.listen();
			   	    log.error("Reconnect to Skype client failed.");
					this.controller.restart();
				}
			}
			catch(SkypeException e)
			{
				  retry=false;
				  String emsg=e.getLocalizedMessage();
				  if (emsg==null)
				  {
					  log.error("Error: makeSkypeCall: skypeDest="+dest,e);
				  }
				  else if (emsg.contains("Unrecognised identity") || emsg.contains("Unrecognized identity"))
				  {	  
					  this.hangupStatus=skype_profile.skypeInvalidDestinationResponse;
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
				  }
				  else if (emsg.contains("Cannot call yourself"))
				  {
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
				  }
				  else if (emsg.contains("Not online"))
				  {
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
				  }
				  else if (emsg.contains("call exists in ROUTING/RINGING/EARLYMEDIA state"))
				  {
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
					  this.hangupStatus=486;
				  }
				  else if (emsg.contains("command execution failed"))
				  {
					    log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
					    retry=this.controller.lostSkypeConnection();
						if (!retry) 
						{	
							this.listen();
					   	    log.error("Reconnect to Skype client failed.");
							this.controller.restart();
						}
				  }
				  else if (emsg.contains("call to the destination user is already ongoing"))
				  {
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage());
				  }
				  else
					  log.error("Error: makeSkypeCall: skypeDest="+dest+" "+e.getLocalizedMessage(),e);
				  break;
			}
		}
		return retvar;
	}
	
	private void addContacts(String destList)
	{
		String[] targets=destList.split(",");
		for (int x=0;x<targets.length;x++)
		{
			   char firstChar=targets[x].toLowerCase().charAt(0);
			   if (firstChar>='a' && firstChar<='z')
				   addContact(targets[x]);
		}
	}
	
	private boolean addContact(String userId)
	{
		   try
		   {
		       ContactList contactList=Skype.getContactList();
			   Friend friend=contactList.getFriend(userId);
			   if (friend==null)
			   {	   
				   contactList.addFriend(userId,skype_profile.autoAddContactAuthMessage);
				   log.info("Skype User: "+userId+" has been added and authorized in contacts list");
			   }
			   else if (!friend.isAuthorized() || friend.isBlocked())
			   {	   
				   friend.setAuthorized(true);
				   friend.setBlocked(false);
				   log.info("Skype User: "+userId+" has been authorized in contacts list");
			   }
		   }
		   catch(SkypeException se)
		   {
			   log.error("authAddAuth error:",se);
			   return false;
		   }

		   return true;
	}
	
	private void sendSkypeIM(String argDest)
	{
		//gather skype user list
		String[] targets=argDest.split(",");
		String dest="";
		for (int t=0;t<targets.length;t++)
		{
			if (!targets[t].startsWith("+") && !targets[t].startsWith("00")) // skypeout starts with + or 00
			{
				int alphalen=targets[t].replaceAll("[^\\p{Alpha}]", "").length();
				int numlen=targets[t].replaceAll("[^0-9]", "").length();
				if (alphalen>0 || numlen<7)
				{
					if (alphalen==0) // get userid of speed dial
						targets[t]=getUserFromSpeedDial(targets[t]);

					// skype user must be a letter
					char firstChar=targets[t].toLowerCase().charAt(0);
					if (firstChar>='a' && firstChar<='z')
					{
						// add to IM targers
						if (dest.length()>0)
							dest+=",";
						dest+=targets[t].trim();
					}
				}
			}
		}
		
		if (dest.length()==0)
			return;
		
		log.info("Sending Skype IM to: "+dest);
		String msg=skype_profile.skypeImMessage;
		// replace [callerid] with sip callers ID
		msg=msg.replaceAll("\\x5bcallerid\\x5d",baseCallEntry.callFrom.replaceAll("(^\"|\" .*$)", ""));
		if (!baseCallEntry.callFrom.toLowerCase().contains("sip:"))
			msg=msg.replaceAll(" *\\x5bcallernumber\\x5d","");
		else
		   msg=msg.replaceAll("\\x5bcallernumber\\x5d",baseCallEntry.callFrom.toLowerCase().replaceAll("^.*sip:", "").replaceAll("@.*$", ""));
		
		log.info("IM: "+msg);
		try
		{
			Chat chat = Skype.chat(dest);
			chat.send(msg);  
			
		}
		catch(SkypeException e)
		{
	        if (e.getLocalizedMessage()==null)
				log.error("Error: sendSkypeIM: skypeDest="+dest,e);
	        else	
	        	log.error("Error: sendSkypeIM: skypeDest="+dest+" "+e.getLocalizedMessage(),e);
		}
		
		try	{Thread.sleep(this.skype_profile.sendSkypeImDelay*1000);}catch(Exception e)	{}
	}
	
	private String getUserFromSpeedDial(String dest)
	{
		// get userid of speed dial, if not matched returns original data
		try
		{
			Friend[] fr = Skype.getContactList().getAllFriends();
			for (int s=0;s<fr.length;s++)
			{	
				if (fr[s].getSpeedDial().toString().equals(dest))
				{
					dest=fr[s].getId();
					break;
				}
			}
		}
		catch(SkypeException e)
		{
			if (e.getLocalizedMessage()==null)
				log.error("Error: getUserFromSpeedDial: skypeDest="+dest,e);
			else	
				log.error("Error: getUserFromSpeedDial: skypeDest="+dest+" "+e.getLocalizedMessage(),e);
		}
		return dest;
	}

	public void cancelSkypeCall()
	{
		skypeCallAudioRedirected=false;
   	    
   	    Vector<SkypeChannel> curSkypeChannels=null;

		synchronized (skypeChannels)
		{
			if (skypeChannels.isEmpty())
				return;

			curSkypeChannels=skypeChannels;
			skypeChannels=new Vector<SkypeChannel>();
		}   

   	    while (curSkypeChannels.size()>0)
   	    {	
   	    	Call curCall=null;
	   	    curCall=curSkypeChannels.get(0).getSkypeCall();
	   	    curSkypeChannels.remove(0);
   	    	
	   	    if (curCall!=null)
	   	    {	
	   	    	glbPossibleRunaway.add(curCall.getId());	
	
			    try
				{
			    	curCall.cancel();
				}
				catch(Throwable e)
				{
				    String msg=e.getLocalizedMessage();
				    if (msg==null || msg.indexOf("Cannot hangup inactive call")<0)
				    	log.debug("cancelSkypeCall:",e);
				}
	   	    }
   	    }

   	    while (glbPossibleRunaway.size()>10) // limit tracking to last 10 skype call ids
   	    	glbPossibleRunaway.remove(0);

	}


	
	public boolean skypeAnswer()
	{
		boolean ansStatus=true;
		
		log.debug("skypeAnswer");
		
		if (!skype_profile.skypeClientSupportsMultiCalls)
		{	
			if (skypeChannels.size()==0)
			{
				log.debug("No skype call to answer");
			    this.cancelSkypeCall();
				return false;
			}

			try
			{
				controller.holdOtherSkypeCalls(this.skypeChannels.get(0).getSkypeCall());
			}
			catch (Exception e)
			{
				log.error("skypeAnswer: holdOtherSkypeCalls failed. ",e);
			    this.cancelSkypeCall();
			    ansStatus=false;
			    return false;
			}
		}
		
		Call curCall=null;
		boolean cancel=false;
		synchronized (skypeChannels)
		{
			if (skypeChannels.size()==0)
			{
				log.debug("No skype call to answer");
				cancel=true;
			}
			else
				curCall=skypeChannels.get(0).getSkypeCall();
		}
		
		if (cancel)
		{
		    this.cancelSkypeCall();
			return false;
		}
		
		Call.Status curStat=null;
		try
		{
			curStat=curCall.getStatus();
			if (curStat==Call.Status.INPROGRESS)
				return true;
			else if (curStat==Call.Status.MISSED || curStat==Call.Status.CANCELLED 
					|| curStat==Call.Status.FAILED || curStat==Call.Status.FINISHED 
					|| curStat==Call.Status.BUSY || curStat==Call.Status.REFUSED 
					|| curStat==Call.Status.UNPLACED)
			{	
				ansStatus=false;
			}
			else
			{	
				baseCallEntry.callFrom=curCall.getPartnerId();
				curCall.answer();
				this.redirSkypeCallAudio();
				this.ua.startSkypeMedia(false);
			}
		}
		catch(Exception e)
		{
			if (skypeChannels.size()!=0) // can be zero if skype caller hungup before call gets answered
			{
			    log.error("skypeAnswer: CallStatus="+curStat,e);
			}
			else
				log.debug("No skype call to answer");
		    this.cancelSkypeCall();
		    ansStatus=false;
		}
		
		return ansStatus;
	}
	
	public void waitForSkypeClipsComplete()
	{
		try
		{
			Call curSkypeCall=null;
			synchronized (skypeChannels)
			{
				if (skypeChannels.size()==0)
					return;
					
				curSkypeCall=skypeChannels.get(0).getSkypeCall();
			}
			
			while (skypeChannels.size()>0 && curSkypeCall.getStatus()==Call.Status.INPROGRESS && !this.ua.getSkypeClipQueueComplete())
			{	
				Thread.sleep(500);
			}
		}
		catch(Exception e)
		{
			log.error("waitForSkypeClipsComplete:",e);
		}
	   try{Thread.sleep(500);}catch(Exception e){}
   }
   
	public void waitForSipClipsComplete()
	{
			while (ua.call_state==UserAgent.UA_ONCALL && !this.ua.getSipClipQueueComplete())
			{	
				try
				{
				Thread.sleep(500);
				}
				catch(Exception e)
				{
				}
			}
			try{Thread.sleep(500);}catch(Exception e){}		
	}
	
	public boolean isIdle()
	{
		if (ua.call_state==UserAgent.UA_IDLE && this.skypeChannels.size()==0 && !this.locked)
			return true;
		else
			return false;
	}
	
	public boolean handleSkypeCall(String targetDest)
	{
		if (targetDest.toLowerCase().startsWith("callback:"))
		{	
			startCallBack(targetDest,false);
			return true;
		}
		else if (skypeAnswer())
		{	
			this.skypeCmdRunner=new SkypeCommandRunner(targetDest,this);
			return true;
		}
		else
			return false;
	}
	
	public synchronized void addCurrentSkypeCall(Call call)
	{
		if (!hasSkypeCallId(call.getId()))
		{	
			if (skypeChannels.size()==0)
			{	
				try
				{
				   Skype.addVoiceMailListener(this);
				}
				catch(SkypeException e)
				{
					log.error("addVoiceMailListener",e);
				}
			}
			skypeChannels.add(new SkypeChannel(this,call));
		}
	}

	public boolean isConferenceCall()
	{
		return conferenceCall;
	}

	public String getConferenceId()
	{
		Call curCall=null;
		synchronized (skypeChannels)
		{
			if (skypeChannels.size()>0)
			{
				curCall=skypeChannels.get(0).getSkypeCall();
			}
		}	

		if (curCall!=null)
		{	
			try
			{
		       return curCall.getConferenceId();
			}
			catch(SkypeException se)
			{
				log.error("getConferenceId",se);
			}
		}
		return null;
	}

	
	public boolean hasSkypeCallId(String id)
	{
		for (int c=0;c<skypeChannels.size();c++)
		{	
			if (skypeChannels.get(c).getSkypeCall().getId().equals(id))
				return true;
		}
		return false;
	}
	
	public int getSkypeChannelsCount()
	{
		return skypeChannels.size();
	}
	
	
	public String getSkypeCallIds()
	{
		String retvar="";
		for (int c=0;c<skypeChannels.size();c++)
		{	
			if (retvar.length()>0)
				retvar+=",";
			retvar+=skypeChannels.get(c).getSkypeCall().getId();
	
		}
		return retvar;
	}
	
	public void lock()
	{
		this.locked=true;
	}
	public void unLock()
	{
		this.locked=false;
	}
	
	public void skypeCallMaked()
	{
		   //	let's redir the audio asap
		   //redirSkypeCallAudio();
	}
	
	public void redirSkypeCallAudio()
	{
		if (skypeChannels.size()!=0 && !skypeCallAudioRedirected)
		{	
		   try
		   {
		    String skypeCallid=skypeChannels.get(0).getSkypeCall().getId();
	        Connector.getInstance().execute("ALTER CALL "+skypeCallid+" SET_OUTPUT PORT=\""+ua.skypeOutPort+"\""); // this is the received audio from remote skpe user
    	    Connector.getInstance().execute("ALTER CALL "+skypeCallid+" SET_INPUT PORT=\""+ua.skypeInPort+"\""); // this is the audio to be sent to the remote skype user
    	    
    	    log.debug("###  redirSkypeAudio success");

    	    skypeCallAudioRedirected=true;
		   }
		   catch(Exception e)
		   {
				log.debug("redirSkypeAudio: error",e);
		   }
		}
	}
	
	private void unRedirSkypeCallAudio()
	{
		  if (skypeChannels.size()!=0 && skypeCallAudioRedirected)
		  {	
			   try
			   {
			    String skypeCallid=skypeChannels.get(0).getSkypeCall().getId();
		        Connector.getInstance().execute("ALTER CALL "+skypeCallid+" SET_OUTPUT SOUNDCARD=\"default\""); // this is the received audio from remote skpe user
	    	    Connector.getInstance().execute("ALTER CALL "+skypeCallid+" SET_INPUT SOUNDCARD=\"default\""); // this is the audio to be sent to the remote skype user
	    	    
	    	    log.debug("unRedirCallAudio success");

	    	    skypeCallAudioRedirected=false;
	     	    
			   }
			   catch(Exception e)
			   {
					log.info("unRedirCallAudio: error",e);
			   }
		  }
	  
    	  this.ua.skypeRtpSender.stopSkypeMedia();
     	  this.ua.skypeRtpReceiver.stopSkypeMedia();
		  try {sleep(100);}catch(Exception e){}
 		  log.debug("unRedirCallAudio Stopped Skype Media");
	}	

	public void resumeSkypeCall()
	{
		try
		{
			for (int c=0;c<skypeChannels.size();c++)
				skypeChannels.get(c).getSkypeCall().resume();
		}
		catch (Exception e)
		{
		   log.error("Error resuming skype call: ",e);
		   listen();
		}
	}

	public void holdSkypeCall() throws Exception
	{
		for (int c=0;c<skypeChannels.size();c++)
			skypeChannels.get(c).getSkypeCall().hold();
	}

	public void sendSkypeDtmfDigits(String digits)
	{
		for (int p=0;p<digits.length();p++)
		{
		   char digit=digits.charAt(p);
		   int sDig=-1;
		   if (digit=='*')
	        	sDig=Call.DTMF.TYPE_ASTERISK.ordinal();
	        else if (digit=='#')
	        	sDig=Call.DTMF.TYPE_SHARP.ordinal();
	        else if (digit>='0' && digit<='9')
	        	sDig=(digit-48);
		   
		   try
		   {
			   for (int c=0;c<skypeChannels.size();c++)
					skypeChannels.get(c).getSkypeCall().send(Call.DTMF.values()[sDig]);
			   log.debug("DTMF:"+digit+" sent to skype");
			   Thread.sleep(800);
		   }
		   catch (Exception e)
		   {
			   log.error("Error sending dtmf: "+digit+" to skype: ",e);
		   }
		}
	}
	
	private synchronized void startCallTime()
	{
		if (callStart>0)
			return;
		
		if (skypeChannels.size()==0)
			return;
		
		try
		{
		  if (skypeChannels.get(0).getSkypeCall().getStatus()!=Call.Status.INPROGRESS)
			 return;
		}
		catch (SkypeException e)
		{
			log.error("startCallTime:",e);
			return;
		}
		
		if (this.ua.call_state!=UserAgent.UA_ONCALL)
			return;
		
		// to get here, not already here before and skype and sip call in progress
		callStart=System.currentTimeMillis();
		baseCallEntry.startTime=new Date();
		
		try
		{
		  baseCallEntry.callType=skypeChannels.get(0).getSkypeCall().getType();
		}
		catch (SkypeException e)
		{
		  log.error("startCallTime:",e);
		}
		
		clearSipCommandRunner();
		clearSkypeCommandRunner();
		
	    startCallTimer();
	}
	
	private void logCall()
	{
		
		Hashtable<String,CallHistoryEntry> curCalls=null;
		
		synchronized (skypeCallTracker)
		{
			if (skypeCallTracker.isEmpty())
				return;

			curCalls=skypeCallTracker;
			skypeCallTracker=new Hashtable<String,CallHistoryEntry>();
		}   
			
		Enumeration<CallHistoryEntry> calls=curCalls.elements();
		boolean anyCallWasPSTN=false;
		while (calls.hasMoreElements())
		{
			  CallHistoryEntry ce=calls.nextElement();
			  String curId=ce.skypeTemporaryCallid;
			  
			  ce.callId=util.parseSkypeResponse("GET CALL "+curId+" TIMESTAMP","CALL "+curId+" TIMESTAMP").trim();
              long unixStamp=Long.parseLong(ce.callId);
              Calendar callStamp=Calendar.getInstance();
              callStamp.setTimeInMillis(unixStamp*1000);
              ce.startTime=callStamp.getTime();
              
              ce.durationSeconds=Long.parseLong(util.parseSkypeResponse("GET CALL "+curId+" DURATION","CALL "+curId+" DURATION"));
	    	  long minutes=ce.durationSeconds/60;
	    	  String seconds=Long.toString(ce.durationSeconds%60+100).substring(1);
	    	  
	    	  if (ce.callType==Call.Type.OUTGOING_PSTN || debugRate)
	    	  {	  
	    		  anyCallWasPSTN=true;
	    		  double callRate=Long.parseLong(util.parseSkypeResponse("GET CALL "+curId+" RATE","CALL "+curId+" RATE"));
	              if (callRate>0 || debugRate)
	              {	  
					  int ratePrecision=Integer.parseInt(util.parseSkypeResponse("GET CALL "+curId+" RATE_PRECISION","CALL "+curId+" RATE_PRECISION"));
					  if (ratePrecision==0)
						ratePrecision=1;
					  callRate=callRate / Math.pow(10, ratePrecision);

					  long durMin=(ce.durationSeconds+59)/60;
					  double callCost = (durMin * callRate)+skype_profile.connectionFee;
			    	  ce.callCost=util.formatAmount(callCost,2)+" "+glbSkypeCallCurrency;
	              }
		    	  else
		    		  ce.callCost="FREE";
	    	  }
	    	  else
	    		  ce.callCost="FREE";
	    	  
	    	  if (ce.callTo==null)
		          ce.callTo="NoOne";

	    	  log.info(ce.callType+" From: "+ce.callFrom+" To: "+ce.callTo+" CallTime: "+minutes+":"+seconds+" Cost: "+ce.callCost);
	    	  this.controller.getCallHistoryHandler().addCall(ce);
		}  
	    	  
	    if (anyCallWasPSTN)
	    {	
	   	   double curBal=util.getSkypeCreditBalance();
	       this.controller.showCallHist();
    	   log.info(util.formatSkypeCreditBalance(curBal));
		   this.controller.updateSkypeCreditBalance(curBal);
	    }	  
	}
	
	void halt()
	{
		this.ua.halt();
		this.interrupt();
	}
	
	public long getLastSipCallTime()
	{
		return lastSipCallAttempt;
	}
	
	public void setPinCalleeDial()
	{
		doPinCalleeDial=true;
	}

	public boolean doSkypeSIPJoin(String skypeUserId)
	{
	    String sipDest=this.controller.getAuthMap().getSipDest(skypeUserId);
		if (sipDest==null || sipDest.length()==0)
		{
			  log.info("doSkypeSIPJoin - rejected call - no SIP Destination");
			  this.listen();
			  return false;
		}
		else
		{
			joinSkypeUserId=skypeUserId;
			if (sipDest.toLowerCase().indexOf("sip:")>=0)
			{
			     sipDest=this.controller.getSipUserContact(sipDest);
			     baseCallEntry.callFrom=sipDest;
			     
			     NameAddress tmpfrom=new NameAddress(this.ua.user_profile.contact_url);
			     tmpfrom.setDisplayName(skypeUserId);
			     
			     this.ua.user_profile.from_url=tmpfrom.toString();

		    	 log.info("doSkypeSIPJoin - Direct SIP Dial to:"+sipDest.replaceAll(";.*","")+" from:"+this.ua.user_profile.from_url);
		    	 this.call(sipDest);
		    	 sipCallRingTimer=new SipCallRingTimer(20,this);
			}
			else
			{
				log.info("doSkypeSIPJoin - Command List:"+sipDest);
				this.handleSkypeCall(sipDest);
			}
			return true;
		}	
	}
	
	public void onSipCallRingTimeout()
	{
		// when called - cancels the sip call if not connected yet
		if (this.ua.call_state!=UserAgent.UA_ONCALL)
		{
			log.info("SIP destination did not answer. Call Cancelled.");
			this.listen();
		}
		clearSipCallRingTimer();
	}
	
   private void clearSipCallRingTimer()
   {
		   if (sipCallRingTimer!=null)
			   sipCallRingTimer.stopTimer();
		   sipCallRingTimer=null;
   }

	private void getSkypeCallRate(CallHistoryEntry callEntry)
	{
		try
		{
			if (glbSkypeCallCurrency==null || glbSkypeCallCurrency.length()==0)
				glbSkypeCallCurrency=util.parseSkypeResponse("GET CALL "+callEntry.skypeTemporaryCallid+" RATE_CURRENCY","CALL "+callEntry.skypeTemporaryCallid+" RATE_CURRENCY");

			if (callEntry.callType==Call.Type.OUTGOING_PSTN || debugRate)
			{
				callEntry.callRate=Long.parseLong(util.parseSkypeResponse("GET CALL "+callEntry.skypeTemporaryCallid+" RATE","CALL "+callEntry.skypeTemporaryCallid+" RATE"));
				if (callEntry.callRate==0)
					log.info("Call Rate: Free");
				else
				{	
					int callPrecision=Integer.parseInt(util.parseSkypeResponse("GET CALL "+callEntry.skypeTemporaryCallid+" RATE_PRECISION","CALL "+callEntry.skypeTemporaryCallid+" RATE_PRECISION"));
					if (callPrecision==0)
						callPrecision=1;
					callEntry.callRate=callEntry.callRate / Math.pow(10, callPrecision);
					log.info("Call Rate: "+util.formatAmount(callEntry.callRate,callPrecision)+" "+glbSkypeCallCurrency);
				}	
			}
		}
		catch(Throwable e)
		{
			log.debug("getSkypeCallRate",e);
		}	
	}
	


   public void onCallTimeoutWarning()
   {
	  log.info("Call Time Limit Warning.");
	  if (skype_profile.overLimitWarningFile.length()>0)
	  {	  
		 ua.queueSipClip(skype_profile.overLimitWarningFile);
	     ua.queueSkypeClip(skype_profile.overLimitWarningFile);
	  }
   }

   public void onCallTimeout()
   {
	  log.info("Call Time Limit reached - call Terminated.");
	  listen();
   }

   private synchronized void clearCallTimer()
   {
	   if (callTimer!=null)
		   callTimer.stopTimer();
	   callTimer=null;
   }
   
   private void startCallTimer()
   {
	   int cutOff=calcMaxCallTime();
	   if (cutOff>0)
	   {
	     log.info("This call is limited to: "+cutOff+" minutes");
	     callTimer=new CallTimer(cutOff,skype_profile.warnMinutesBeforeCutoff,this);
	     callTimer.start();
	   }
	   else
		 callTimer=null;
   }
	
   private int calcMaxCallTime()
   {
	   //  calc cutoff time section     
	   int cutOff=skype_profile.maxCallTimeLimitMinutes;
	   if (this.baseCallEntry.callType==Call.Type.OUTGOING_PSTN)
	   {
	       if (skype_profile.MaxPstnCallTimeLimitMinutes>0 && (skype_profile.MaxPstnCallTimeLimitMinutes<cutOff || cutOff==0))
	           cutOff=skype_profile.MaxPstnCallTimeLimitMinutes;

	       if (skype_profile.dailyPstnLimitMinutes>0)
	       {
	           int pstnRemaining=skype_profile.dailyPstnLimitMinutes-this.controller.getCallHistoryHandler().getPstnTodayTimeQualified();
	           if (pstnRemaining<=0)
	               log.error("remaining time lte 0???");
	           if (pstnRemaining<cutOff || cutOff==0)
	              cutOff=pstnRemaining;
	       }   
	   }
	   else if (this.baseCallEntry.callType!=Call.Type.OUTGOING_P2P)
		   cutOff=0; // incoming is not limited

	   return cutOff;
   }
   
	private boolean isOverUsageLimit(String filteredDest)
	{
		String tmp=filteredDest.replaceAll(" ", "").replaceAll("^[+]","").replaceAll("^00", "");
		if (tmp.length()<1)
			return false;
		if (Character.isDigit(tmp.charAt(0))) // PSTN call test
		{	
			   CallHistoryHandler chh=this.controller.getCallHistoryHandler();
			   if (chh.isTollFreeNumber(tmp))
				   return false;
			   // call count limit check
			   if (skype_profile.dailyPstnUniqueNumberLimit>0 && chh.getPstnTodayCountQualified()>=skype_profile.dailyPstnUniqueNumberLimit)
			        return true;

			   // test time usage    
		       if (skype_profile.dailyPstnLimitMinutes>0)
		       {
			           int pstnRemaining=skype_profile.dailyPstnLimitMinutes-chh.getPstnTodayTimeQualified();
			           if (pstnRemaining<=0 || pstnRemaining<skype_profile.refuseNewPstnCallsWhenRemainingMinutesUnder)
			               return true;
			   }
		}	
		return false;
	}

	public Vector<String> getPossibleRunawaySkypeCallids()
	{
		return glbPossibleRunaway;
	}
   
	private void clearSkypeRinger()
	{
	   if (skypeRinger!=null)
		   skypeRinger.stopRinger();
	   skypeRinger=null;
	}
   
    private void startCallBack(String callBackCmd,boolean isFromSip)
    {
    	
    	if (callBackTargets!=null)
    	{
    		log.error("Recursive CallBacks not supported.");
    		listen();
    	}
    	
		//Skype=user1,user2;SIP=324234@sipaddress:sipport
    	callBackCmd=callBackCmd.toLowerCase().replaceAll("callback:", "");
    	
    	log.info("CALLBACK - callback targets: "+callBackCmd);
    	
    	Vector<String> cbTargets=new Vector<String>();
    	
		//Skype=user1,user2;SIP=324234@sipaddress:sipport
		String[] typeTargets=callBackCmd.split("[|]");
		int sipCnt=0;
		for (int x=0;x<typeTargets.length;x++)
		{
			if (typeTargets[x].length()>0)
			{	
				   log.debug("TargetSet: "+typeTargets[x]);
				   
				   String[] set=typeTargets[x].split("=");
				   if (set.length>1)
				   {	   
					   
					   if (set[0].startsWith("skype"))
					   {
						  String[] skypeTargets=set[1].split(",");
						  for (int st=0;st<skypeTargets.length;st++)
							  cbTargets.add("skype:"+skypeTargets[st].replaceAll(" ", "").trim());
					   }
					   else if (set[0].startsWith("sip"))
					   {
						   if (sipCnt>0)
						   {
							   log.error("Only 1 sip target is supported.");
							   listen();
							   return;
						   }
						   cbTargets.add("sip:"+set[1].replaceAll(" ", "").trim());
						   sipCnt++;
					   }
					   else
					   {
						   log.error("Unknown target type: "+set[0]);
						   listen();
						   return;
					   }   
				   }
			}
		}
    	
		if (!isFromSip)
		{	
			try
			{
			  baseCallEntry.callFrom=skypeChannels.get(0).getSkypeCall().getPartnerId();
			}
			catch(Exception e)
			{
			   log.error("Error getting Skype Caller Id:",e);
			   listen();
			   return;	
			}
		}
		
    	callBackTargets=cbTargets;
    	
    	if (callBackTargets.size()==0)
    	{
    		log.error("No valid targets! Check configuration.");
    		listen();
    		return;
    	}
    	else if (callBackTargets.size()==1)
			log.info("CALLBACK: Two Stage Dialing");
		else
			log.info("CALLBACK: Multiple targets");

		callBackHandler=new CallBackHandler(this,isFromSip,20);
    }

    protected void callBackDial(boolean success)
    {
    	this.callBackHandler=null;
    	if (!success)
    	{
    	   listen();
    	   return;
    	}
    	
    	callBack=true;
    	
		log.info("CALLBACK: Caller hungup - starting dialing sequence");
		
		try {sleep(750);}catch(Exception e){}
		cancelSkypeCall();
		try {sleep(750);}catch(Exception e){}
		
		String sipTarget="";
		String skypeTargets="";
		
		for (int x=0;x<callBackTargets.size();x++)
		{
			       String curTarget=callBackTargets.get(x);
				   log.debug("TargetSet: "+curTarget);
				   
				   String[] set=curTarget.split("[:]");
				   if (set[0].startsWith("skype"))
				   {
					   if (skypeTargets.length()>0)
						   skypeTargets+=",";
					   skypeTargets+=set[1];   
				   }
				   else if (set[0].startsWith("sip"))
				   {
					   sipTarget=set[1];   
				   }
		}

		log.debug("targets cnt: sip:"+sipTarget.length()+" skype:"+skypeTargets.length());
		
		if (sipTarget.length()==0 && skypeTargets.length()==0)
		{
			log.error("No valid targets???");
			listen();
		}	
		else
		{		
			if (sipTarget.length()>0)
				call(sipTarget);
			
			if (skypeTargets.length()>0)
				makeSkypeCall(skypeTargets); 
		}
    }

    
    private boolean startVoiceMailPlayer()
    {
		if (ua.call_state==UserAgent.UA_INCOMING_CALL)
		    this.ua.accept();
		else
			return false;
		
		voiceMailPlayer=new VoiceMailPlayer(this,skype_profile);
		return true;
    }
    
    private synchronized void clearVoiceMailPlayer()
    {
  	  if (voiceMailPlayer!=null)
	  {	  
		  voiceMailPlayer.stopPlayer();
		  voiceMailPlayer=null;
	  }
    }
    
    // callback from VoiceMailPlayer
    public void voiceMailClosed(boolean hangup)
    {
    	voiceMailPlayer=null;
    	if (hangup)
    	   listen();
    }
    
    // callback from SkypeVMChannel
    public void voiceMailStatusChanged(SkypeVMChannel vmChannel,VoiceMail.Status status) throws SkypeException
    {
    	VoiceMail curVM=vmChannel.getSkypeVM();
    	String curVMId=curVM.getId();
    	VoiceMail.Type vmType=curVM.getType();

    	switch (vmType)
    	{
    		case OUTGOING:
    		    switch (status)
    		    {
    			    case UPLOADED:
    			       //vm has completed
    			       log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);
    			       vmDelayedMode=false;
    			       listen();
    			       break;
    			    case FAILED:
    			      stopVmRecording();
			    	  String msg="VoicemailStatus["+curVMId+"] - "+vmType+" "+status;
		    	      try
		    	      {
		    	         msg+=" (Reason: "+curVM.getFailureReason()+")";
		    	      }
		    	      catch (Exception e)
		    	      {
		    	    	  msg+=" (Reason: Unknown)";
		    	    	  log.debug("Error retrieving failure reason",e);
		    	      }
		    	      log.info(msg);
   			          vmDelayedMode=false;
    			      listen();
    			      break;
    			    case RECORDED:
    			      stopVmRecording();
    			      log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);
    			      break;
    			    case RECORDING:
    			      log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);	
    			      if (hangupPending)
    			    	  vmOutgoing.cancel();
    			      else
    			          startVmRecording();
    			      break;
    			    default:
      			      log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);	
    			      break;
    			} 	
    	        break;
    	    case CUSTOM_GREETING: // handle same as DEFAULT_GREETING
    	    case DEFAULT_GREETING:
    	       log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);
    	       switch (status)
    		   {
    			   case PLAYED:
    			     //done with greeting
    				 this.ua.queueSipClip(skype_profile.vmRecordingBeepClip);
    				 stopVmGreeting();
    			     break;
    			   case FAILED:
    			     listen();
    			     break;
    			   case PLAYING:
    				 startVmGreeting();
    			     break;
    			   default:
    			     break;
    		   }	   
    		   break;
    		default:
    		   log.info("VoicemailStatus["+curVMId+"] - "+vmType+" "+status);	
    		   break;  
    	}
    }

    // callback from Skype4Java
	  public void voiceMailReceived(VoiceMail receivedVoiceMail) throws SkypeException
	  {
		  log.debug("### voiceMailReceived ["+receivedVoiceMail.getId()+"]");
	  }

	    // callback from Skype4Java
	  public synchronized void voiceMailMade(VoiceMail vm) throws SkypeException
	  {
		   log.debug("### voiceMailMade ["+vm.getId()+"]");

		   if (vmGreeting!=null && vmGreeting.getSkypeVM().getId().equals(vm.getId()))
			   return;
		   if (vmOutgoing!=null && vmOutgoing.getSkypeVM().getId().equals(vm.getId()))
			   return;

		   VoiceMail.Type type=vm.getType();
		   switch (type)
		   {
		     case CUSTOM_GREETING:
		     case DEFAULT_GREETING:
		       if (vmGreeting==null)
		       {	   
		    	   vmGreeting=new SkypeVMChannel(this,vm,type);
				   voiceMailStatusChanged(vmGreeting, vmGreeting.getStatus());
		       }	   
			   break;
		     case OUTGOING:
		       if (vmOutgoing==null)
		       {   
				   vmOutgoing=new SkypeVMChannel(this,vm,type);
				   voiceMailStatusChanged(vmOutgoing, vmOutgoing.getStatus());
		       }
			   break;
		   }

	  }

	  
	  private synchronized void closeVMGreeting()
	  {
	     SkypeVMChannel vms=null;
    	 if (vmGreeting==null)
	    		return;
	    	 
         vms=vmGreeting;
         vmGreeting=null;
         vms.cancel();

         VoiceMail.destroyInstance(vms.getSkypeVM().getId());
	  }

	  private synchronized void closeVMOutgoing()
	  {
	     SkypeVMChannel vms=null;
	     if (vmOutgoing==null)
	    	return;
	    	 
	     vms=vmOutgoing;
	     vmOutgoing=null;
	     vms.cancel();
         VoiceMail.destroyInstance(vms.getSkypeVM().getId());
	  }
	  
	  private void redirVmRXAudio()
	  {
		  log.debug("redirVmRXAudio");
		  if (vmGreeting!=null)
		  {
			   String vmId=vmGreeting.getSkypeVM().getId();
			   if (util.parseSkypeResponse("ALTER VOICEMAIL "+vmId+" SET_OUTPUT PORT=\""+ua.skypeOutPort+"\"", "ALTER VOICEMAIL "+vmId).startsWith("SET_OUTPUT"))
		        	log.debug("redirVmRXAudio_OUTPUT success");
		  }
	  }

	  private void unredirVmRXAudio()
	  {
		  log.debug("####  unredirVmRXAudio");
		  
	 	  if (vmGreeting!=null && vmGreetingStarted)
		  {	
				   String vmId=vmGreeting.getSkypeVM().getId();
				   if (util.parseSkypeResponse("ALTER VOICEMAIL "+vmId+" SET_OUTPUT SOUNDCARD=\"default\"", "ALTER VOICEMAIL "+vmId).startsWith("SET_OUTPUT"))
			        	log.debug("unredirVmRXAudio_OUTPUT ["+vmId+"] success");
		  } 
		  
		  this.ua.skypeRtpSender.stopSkypeMedia();
		  this.ua.skypeRtpReceiver.stopSkypeMedia();
		  try {sleep(100);}catch(Exception e){}
		  vmGreetingStarted=false;
	  }
	  
	  
	  private void startVmGreeting()
	  {
		  
		     if (vmGreetingStarted)
		    	 return;
		     
		     vmGreetingStarted=true;
		     log.info("Voicemail Greeting Playing");
		  
		  
		     if (this.ua.call_state==UserAgent.UA_INCOMING_CALL)
			     this.ua.accept();
		  
	         unRedirSkypeCallAudio();
		   	 redirVmRXAudio();
		   	 try
		   	 {
		   		 this.ua.skypeRtpSender.startSkypeMedia();;
		   	 }
		   	 catch(Exception e)
		   	 {
		   		 log.error("startVmGreeting Error",e);
		   		 listen();
		   	 }
	  }
	  
	  private void stopVmGreeting()
	  {
	         unredirVmRXAudio();
	  }
	  

	  private void startVmRecording()
	  {
			  log.info("Voicemail Recording");

			  if (vmOutgoing!=null)
			  {	
				    String vmId=vmOutgoing.getSkypeVM().getId();
			        if (util.parseSkypeResponse("ALTER VOICEMAIL "+vmId+" SET_INPUT PORT=\""+ua.skypeInPort+"\"","ALTER VOICEMAIL "+vmId).startsWith("SET_INPUT"))
			        {
			        	log.debug("startVmRecording_INPUT ["+vmId+"] success");
			        }
			  }
		  
		   	 try
		   	 {
		   		 this.ua.skypeRtpReceiver.startSkypeMedia();;
		   	 }
		   	 catch(Exception e)
		   	 {
		   		 log.error("startVmRecording Error",e);
		   		 listen();
		   	 }
	  }

	  private void stopVmRecording()
	  {
			  log.debug("stopVmRecording");
			  this.ua.skypeRtpSender.stopSkypeMedia();
			  this.ua.skypeRtpReceiver.stopSkypeMedia();
			  try {sleep(100);}catch(Exception e){}
	  }
	  

}


