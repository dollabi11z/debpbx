/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;

import org.apache.log4j.Logger;

import com.skype.VoiceMail;
import com.skype.VoiceMailStatusChangedListener;
import com.skype.SkypeException;

public class SkypeVMChannel implements VoiceMailStatusChangedListener
{
	private Logger log = null;
	private VoiceMail skypeVM=null;
	private SSCallChannel ssCallChannel=null;
	private volatile VoiceMail.Status vmStatus=null;
	
	SkypeVMChannel(SSCallChannel argCC,VoiceMail argSkypeVM,VoiceMail.Type argType) throws SkypeException
	{
		ssCallChannel=argCC;
		skypeVM=argSkypeVM;
		log = Logger.getLogger(this.getClass().getName()+".#"+skypeVM.getId());
		addListener();
	}

	public VoiceMail getSkypeVM()
	{
		return skypeVM;
	}

	public VoiceMail.Status getStatus()
	{
		if (vmStatus==null)
		{
			try
			{
			    vmStatus=skypeVM.getStatus();
			}
			catch(Exception e)
			{
				log.error("VMH (getStatus) Error",e);
			}
		}
		return vmStatus;
	}
	
	
	public void statusChanged(VoiceMail.Status status) throws SkypeException
	{
		vmStatus=status;
		ssCallChannel.voiceMailStatusChanged(this, status);
	}	

	public void cancel()
	{
		VoiceMail.Type curType=VoiceMail.Type.UNKNOWN;
		try {curType=skypeVM.getType();}catch(SkypeException e){log.error("cancel error",e);}
		
		if (curType==VoiceMail.Type.CUSTOM_GREETING || curType==VoiceMail.Type.DEFAULT_GREETING)
		{
			try 
			{
				if (getStatus()==VoiceMail.Status.PLAYING)
				{	
			       log.info("Stop VoiceMail Greeting");
				   skypeVM.stopPlayback();
				}  
			}
			catch(Exception e)
			{}
		}
		else if (curType==VoiceMail.Type.OUTGOING)
		{	
			try
			{
				if (getStatus()==VoiceMail.Status.RECORDING)
				{	
			    	    log.info("Stop Voicemail Recorder");
					    
					    // API https://developer.skype.com/Docs/ApiDoc/ALTER_VOICEMAIL says "STOPRECORDING causes automatic message upload to the server."

						//util.parseSkypeResponseNoId("ALTER VOICEMAIL "+skypeVM.getId()+" UPLOAD", "ALTER VOICEMAIL "+skypeVM.getId()+" UPLOAD");
					
					    skypeVM.stopRecording(); // not working correctly on 4.1.0.179 - does not upload gets CONNECT_ERROR after a minute.
					    
				}
			}
			catch(Exception e)
			{
				log.error("cancel VM Error",e);
			}
		}
	}
	
	public void addListener() throws SkypeException
	{
		skypeVM.addVoiceMailStatusChangedListener(this);	
	}
	
	public void removeListener()
	{
		skypeVM.removeVoiceMailStatusChangedListener(this);	
	}

}
