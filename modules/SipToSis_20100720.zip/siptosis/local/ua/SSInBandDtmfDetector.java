/*
 * Copyright (C) 2010 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * 
 * Author(s):
 * Some Goertzel Portions taken  from
http://en.wikipedia.org/wiki/Goertzel_algorithm
 * Greg Dorfuss
 * 2010/07/20 - fixed some issues
 */


package local.ua;

import java.io.PipedInputStream;

import local.media.PipedInputStreamSizable;
import java.io.IOException;
import org.apache.log4j.Logger;

public class SSInBandDtmfDetector extends Thread
{
    private static final int BUFFSIZE=65536; // 2 seconds worth
    private static final int CHOPSIZE=BUFFSIZE/2;
    private static final double msPerRound=11;
    
    private static final int dtmf_row_col_map[][] = {
		    {1, 2, 3, 12},
	        {4, 5, 6, 13},
	        {7, 8, 9, 14},
	        {10, 0, 11, 15}};

    //private static final float DBV_16=(float) Math.pow(10,(16d/-20d)); //.1585f;
    private static final float DBPL_20=(float) Math.pow(10,(20d/-10d)); //.010f;
    private static final float DBPL_16=(float) Math.pow(10,(16d/-10d)); //.02511f;
    private static final float DBPL_8=(float) Math.pow(10,(8d/-10d)); //.1585f;
    private static final float DBPL_4=(float) Math.pow(10,(4d/-10d)); //0.398f;
    

    // instance globals
    private Logger log=null;
    private float MINENERGY=1.0e8f; //4.0e5f;
	
    private float SAMPLING_RATE = 16000f; 
    private int BYTESPERDATASAMPLE=2;
    
    private int HIT_THRESHHOLDms;
    private int NOHIT_THRESHHOLDms;
    
    private float curValues[];
    private boolean running=true;
    private PipedInputStream dataIs=new PipedInputStreamSizable(BUFFSIZE); 
    private SSInBandDtmfInterface dtmfInt=null;
    
    private int detectRow;
    private int detectCol;
    private int peak_count;
    private float maxRowVal;
    private float maxColVal;
    private float totalEnergy;
    private double PeakThreshholdEnergy;
    private int  iloop;
    
    public SSInBandDtmfDetector(SSInBandDtmfInterface argUa,int argSampleRate,int argBytesPerSample,int argHitThresholdms,int argSilenceThresholdms,float argGain) 
    {
 
    	this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		log = Logger.getLogger(this.getName());
    	dtmfInt=argUa;
    	SAMPLING_RATE=argSampleRate;
    	BYTESPERDATASAMPLE=argBytesPerSample;
    	
    	HIT_THRESHHOLDms=(int) ((int)((argHitThresholdms+msPerRound-1)/msPerRound)*msPerRound);
    	NOHIT_THRESHHOLDms=(int) ((int)((argSilenceThresholdms+msPerRound-1)/msPerRound)*msPerRound);
    	float samplingRateEnergyAdjust=SAMPLING_RATE/8000;
    	
    	MINENERGY/=argGain;
    	MINENERGY*=samplingRateEnergyAdjust;
    	
    	log.debug("InbandDtmfDecoderGainAdjust: "+argGain);
    	
    	start();
    }

    public void stopDetecter()
    {
    	running=false;
    }
    
    public PipedInputStream getPipedInputStream()
    {
    	return dataIs;
    }
    
    
    public void run()
    {
	   	int BytesPerMs=(int)SAMPLING_RATE/1000*BYTESPERDATASAMPLE;
		int STREAM_BYTES=(int)(BytesPerMs*msPerRound);

		byte data[] = new byte[STREAM_BYTES];
        int activeDTMF;
        int si;
        int qi;
        int activeDetect=-1;
        long activeHitCnt=0;
        long silenceHitCnt=1;
        float curSample;
        float Q0;
        boolean oneFalseSilenceHit=false;

	
		 // set minimum for hit and minimum between hits
	
		 int HIT_THRESHHOLD=(int) (HIT_THRESHHOLDms/msPerRound);
		 int NOHIT_THRESHHOLD=(int) (NOHIT_THRESHHOLDms/msPerRound);
		 if (NOHIT_THRESHHOLD<1)
			 NOHIT_THRESHHOLD=1;
	
		 float frequencyArray[] = {697.0F, 770.0F, 852.0F, 941.0F, 1209.0F, 1336.0F, 1477.0F, 1633.0F};
		 int NUM_FREQS=frequencyArray.length;
		 float freqCoeffValueArray[]= new float[NUM_FREQS];
		 float[] Q1= new float[NUM_FREQS];
		 float[] Q2 = new float[NUM_FREQS];
		 curValues=new float[NUM_FREQS];
		 
		 for(int n = 0; n < NUM_FREQS; n++)
		 {
			 freqCoeffValueArray[n] =(float) (2.0 * java.lang.Math.cos(2.0 * java.lang.Math.PI * frequencyArray[n] /SAMPLING_RATE));
		 }
            
         int bytesAvail;

        while (!Thread.interrupted() && running)
		{
		    try
		    {
		       bytesAvail=dataIs.available();
		       
		       if (bytesAvail>=STREAM_BYTES)
		       {	 
				       if (bytesAvail>CHOPSIZE)
				       {
				    	   log.debug("InBand DTMF decoder buffer chopped.");
				    	   dataIs.skip(bytesAvail-STREAM_BYTES);
				       }   

				       dataIs.read(data,0,STREAM_BYTES);

				    
				        // process the samples
				        totalEnergy=0;
				    	if (BYTESPERDATASAMPLE==2)
				    	{	
					        for (si = 0; si < STREAM_BYTES; si+=2) 
					        {
					        	curSample=(data[si + 1] << 8 | data[si] & 0xff); // 2 bytes per sample
					        	totalEnergy+=(curSample*curSample);
					        	//log.warn("samp="+curSample);
					        	
					            for (qi = 0; qi < NUM_FREQS; qi++) 
					            {
					                Q0 = freqCoeffValueArray[qi] * Q1[qi] - Q2[qi] + curSample;
					                Q2[qi] = Q1[qi];
					                Q1[qi] = Q0;
					            }
					        }
				    	}
				    	else
				    	{	
					        for (si = 0; si < STREAM_BYTES; si++) 
					        {
					        	curSample=data[si];
					        	totalEnergy+=(curSample*curSample);
					            
					            for (qi = 0; qi < NUM_FREQS; qi++) 
					            {
					                Q0 = freqCoeffValueArray[qi] * Q1[qi] - Q2[qi] + curSample;
					                Q2[qi] = Q1[qi];
					                Q1[qi] = Q0;
					            }
					        }
				    	}
					
				        for (si = 0; si < NUM_FREQS; si++) 
				        {
				        	curValues[si]=( (Q1[si] * Q1[si]) + (Q2[si] * Q2[si]) - (freqCoeffValueArray[si] * Q1[si] * Q2[si]) );
				            
				            // clear it as we go
				            Q1[si]=0;
				            Q2[si]=0;
				        }
				 
				        activeDTMF = doDTMFDetection();
				        
				        //if (activeDTMF>=0)
				        //log.warn("ad="+activeDTMF);
				        
				        if (activeDTMF<0)
				        {	
		        		    silenceHitCnt++;

			        		if (activeDetect>=0) // wait for previously received detection
			        		{	
				        		if (activeHitCnt>=HIT_THRESHHOLD) // wait for active period to occur
				        		{
				        			if (silenceHitCnt>=NOHIT_THRESHHOLD) // wait for silence period to occur
				        			{	
						        		if (dtmfInt!=null)
						        		{	
						        			dtmfInt.gotDtmfDigit(activeDetect);
						        			//log.warn(" got:"+activeDetect+" ac="+activeHitCnt+" sc="+silenceHitCnt);
						        		}	
							        	else	
							        		log.warn(" got:"+activeDetect+" ac="+activeHitCnt+" sc="+silenceHitCnt);
					
						        		// reset for next
						        		activeDetect=-1;
					        		    //silenceHitCnt=1;
				        			}
				        		}
				        		else
				        		{
				        			// it became undetected before receiving enough detected hits and enough silence - reset 
					        		activeDetect=-1;
				        		}
			        		}
				        }
				        else 
				        {
				        	if (activeDetect<0)
				        	{	
				        		if (silenceHitCnt>2)
				        		{	
				        		    // switch to active detection
					        		activeHitCnt=1;
					        		activeDetect=activeDTMF;
				            		silenceHitCnt=0;
				            		oneFalseSilenceHit=false;
				        		}
				        	}
				        	else if (activeDTMF!=activeDetect)
				        	{
				        		if (activeHitCnt>=HIT_THRESHHOLD && !oneFalseSilenceHit)
				        		{
				        		   // we have enough active detection so treat a one false hit as silence
				        		   silenceHitCnt++;
				        		   oneFalseSilenceHit=true;
				        		}
				        		else
				        		{	
					        	  // digit changed during an active detection 
				        		  if (activeHitCnt==1) //switch to active detection of the new digit if only one hit of previous detection
				        		  {  
					        		activeDetect=activeDTMF;
				            		silenceHitCnt=0;
				            		oneFalseSilenceHit=false;
				        		  }
				        		  else // false hit - reset
				        		  {	  
			            		    silenceHitCnt=1;
				        		    activeDetect=-1;
				        		  }
				        		}  
				        	}
				        	else
				        	{
				        		activeHitCnt++;
				        	}
				        }	
		       }
		       else
			    	try {sleep(40);} catch(Exception se){}
		    }
		    catch(IOException ioe)
		    {
		    	try {sleep(40);} catch(Exception se){}
		    }
		}
    }

    
    
    private int doDTMFDetection()
    {
      
      /* Find the largest in the row group (0-3). */
      detectRow = 0;
      maxRowVal = curValues[0];
      for ( iloop=1; iloop<4; iloop++ )
      {
        if ( curValues[iloop] > maxRowVal )
        {
          maxRowVal = curValues[iloop];
          detectRow = iloop;
        }
      }
      
      /* Check row for minimum energy */
      if ( maxRowVal < MINENERGY )   /* 2.0e5 ... 1.0e8 no change */
      {
        /* energy not high enough */
      	return -1;
      }
     
      /* Find the largest in the column group (4-7). */
      detectCol = 4;
      maxColVal = curValues[4];
      for ( iloop=5; iloop<8; iloop++ )
      {
        if ( curValues[iloop] > maxColVal )
        {
          maxColVal = curValues[iloop];
          detectCol = iloop;
        }
      }
     
      /* Check col for minimum energy */
      if ( maxColVal < MINENERGY )
      {
        /* energy not high enough */
    	return -2;
      }

        /* Twist check
         * CEPT => twist < 6dB
         * AT&T => forward twist < 4dB and reverse twist < 8dB
         *  -ndB < 10 log10( v1 / v2 ), where v1 < v2
         *  -4dB < 10 log10( v1 / v2 )
         *  -0.4  < log10( v1 / v2 )
         *  0.398 < v1 / v2  (4DB) 
         *  0.398 * v2 < v1  (4DB)
         */
       
        if ( maxColVal > maxRowVal)
        {  
	        // Reverse Twist - do the tougher test first
	        if (maxColVal < maxRowVal * DBPL_8 ) // maxcol < rowval -8db
	            return -3;
	
	        //Normal twist
	        if (maxRowVal < maxColVal * DBPL_4 ) // maxrow < maxcol -4db
	        	return -4;
        }
        else
        {
	        // Reverse Twist - do the tougher test first
	        if (maxRowVal < maxColVal * DBPL_8 )
	            return -5;
	
	        //Normal twist
	        if (maxColVal < maxRowVal * DBPL_4 )
	        	return -6;
        }
        
        /* Peak Tests
         * Count the number of peaks within 8DB of max detected
         * there should be only one in col and one in row.
         */

        // col peak
        if ( maxColVal > 1.0e9f) // what does 1.0e9f represent and why the different threshold
        	PeakThreshholdEnergy = maxColVal * DBPL_8;
        else
        	PeakThreshholdEnergy = maxColVal * DBPL_16; // was 20db (.01)
        
        peak_count = 0;
        if ( curValues[4] > PeakThreshholdEnergy )
           peak_count++;
        if ( curValues[5] > PeakThreshholdEnergy )
           peak_count++;
        if ( curValues[6] > PeakThreshholdEnergy )
           peak_count++;
        if ( curValues[7] > PeakThreshholdEnergy )
           peak_count++;
        if ( peak_count != 1 ) // should be one
          	return -7;

        // row peak  
        if ( maxRowVal > 1.0e9f) // what does 1.0e9f represent and why the different threshold
        	PeakThreshholdEnergy = maxRowVal * DBPL_8;
        else
        	PeakThreshholdEnergy = maxRowVal * DBPL_16; // was 20db (.01)
 
        if ( curValues[0] > PeakThreshholdEnergy )
            peak_count++;
        if ( curValues[1] > PeakThreshholdEnergy )
              peak_count++;
        if ( curValues[2] > PeakThreshholdEnergy )
              peak_count++;
        if ( curValues[3] > PeakThreshholdEnergy )
              peak_count++;
        if ( peak_count != 2 ) // should be two now (including col peak)
        	return -8;
     
        /* Signal to noise test
         * Detected tone must be 16dB higher than total signal.
         */

		if ( (maxRowVal+maxColVal) * DBPL_16 < totalEnergy)
			return -9;
        
        return dtmf_row_col_map[detectRow][detectCol-4];
       
    }
    
}




