/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Based on mjsip 1.6 software and skype4java
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;

import java.util.Vector;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/*
 * runs a command sequence defined in SkypeToSipAuth.props
 */
public class SkypeCommandRunner extends Thread
{
	private Vector<QueueCmd> queueList=new Vector<QueueCmd>();
	private SSCallChannel skypeua=null;
	private boolean stop=false;
	private Logger log = null;
	
	SkypeCommandRunner(String cmdData,SSCallChannel argUa) 
	{
		this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		log = Logger.getLogger(this.getName());
		
	    this.skypeua=argUa;
	    
	    parse(cmdData);
	    
	}
	
	
	private void parse(String cmdData)
	{
		//	parse cmdlist
		String[] cmdList=cmdData.split(";");
		for (int c=0;c<cmdList.length;c++)
		{
			if (cmdList[c].startsWith("sip:"))
			{	
				String dest=cmdList[c];
				// get remainder
				for (int r=c+1;r<cmdList.length;r++)
				{
					String tst=cmdList[r].toLowerCase();
					if (tst.startsWith("usr=") || tst.startsWith("pwd=") || tst.startsWith("realm=") || tst.startsWith("from="))
					{	
					  dest+=";"+cmdList[r];
					  c=r;
					}
					else
					{
						c=r-1;
						break;
					}
				}
				dest+=";";
				//log.info("dest="+dest);
				queueList.add(new QueueCmd("sipdial",dest));
			}
			else
			{	
				String[] curCmd=cmdList[c].split(":");
				//log.info("cmd="+curCmd[0]);
				
				if (curCmd.length==2)
					queueList.add(new QueueCmd(curCmd[0].toLowerCase(),curCmd[1]));
				else if (curCmd.length==1)
					queueList.add(new QueueCmd(curCmd[0].toLowerCase(),""));
				else
				{	
					log.error("Invalid command sequence:"+cmdData);
					this.queueList.clear();
					break;
				}
			}
		}
		
	}

	public void run() 
	{
		
		while (queueList.size()>0 && !stop)
		{
			QueueCmd thisCmd=queueList.get(0);
			queueList.remove(0);
			
			log.info(thisCmd.attrib+":"+thisCmd.value);
			
			if (thisCmd.attrib.equals("pause"))
			{
				try 
				{
					sleep(Long.parseLong(thisCmd.value)*1000);
				}
				catch (Exception e)
				{
					log.error("error",e);
				}
			}
			else if (thisCmd.attrib.equals("dtmf"))
			{
				this.skypeua.sendSkypeDtmfDigits(thisCmd.value);
			}
			else if (thisCmd.attrib.equals("pin"))
			{
				this.skypeua.startSkypeAuthSequence(thisCmd.value);
			}
			else if (thisCmd.attrib.equals("play"))
			{
				this.skypeua.ua.queueSkypeClip(thisCmd.value);
				this.skypeua.waitForSkypeClipsComplete();
				if (queueList.size()==0)
				{
					this.skypeua.cancelSkypeCall();
				}
			}
			else if (thisCmd.attrib.equals("sipdial"))
			{
				this.skypeua.call(thisCmd.value);
			}
			else
			{
				log.error("Unknown command:"+thisCmd.attrib+":"+thisCmd.value);
			}
			
		}
		
		if (!this.stop)
			this.skypeua.clearSkypeCommandRunner();

	}
	public void stopCommands()
	{
		this.stop=true;
	}
	
	
	public static void main(String[] args) throws Exception 
	{
		PropertyConfigurator.configure("log.properties"); // needed only first time
		new SkypeCommandRunner("*,pin:1234;sip:0019545656715@sip.voipbuster.com:5060;usr=tstuser;pwd=tstpasswd;realm=sip.voipbuster.com;from=\"testperson\" <sip:tstuser@sip.voipbuster.com:5060>;",null);
	}
}
