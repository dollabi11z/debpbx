/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;

import org.apache.log4j.Logger;

import com.skype.Call;
import com.skype.CallStatusChangedListener;
import com.skype.SkypeException;

public class SkypeChannel implements CallStatusChangedListener
{
	private Logger log = null;
	private Call skypeCall=null;
	private SSCallChannel ssCallChannel=null;
	SkypeChannel(SSCallChannel argCC,Call argSkypeCall) 
	{
		ssCallChannel=argCC;
		skypeCall=argSkypeCall;
		log = Logger.getLogger(this.getClass().getName()+".#"+skypeCall.getId());
		addListener();
	}

	public Call getSkypeCall()
	{
		return skypeCall;
	}
	
	public void statusChanged(Call.Status status) throws SkypeException
	{
		ssCallChannel.callStatusChanged(this, status);
	}	

	public void cancel()
	{
		try
		{
			 skypeCall.cancel();
		}
		catch(Throwable e)
		{
		    String msg=e.getLocalizedMessage();
		    if (msg==null || msg.indexOf("Cannot hangup inactive call")<0)
		    	log.debug("cancelSkypeCall:",e);
		}
		skypeCall.removeCallStatusChangedListener(this);
	}
	
	public void addListener()
	{
		skypeCall.addCallStatusChangedListener(this);	
	}
	public void removeListener()
	{
		skypeCall.removeCallStatusChangedListener(this);	
	}

}
