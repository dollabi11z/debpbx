/*
 * Copyright (C) 2009 Greg Dorfuss - mhspot.com
 * 
 * SipToSis is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SipToSis is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this source code; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Author(s):
 * Greg Dorfuss
 */

package local.ua;

import org.apache.log4j.Logger;
import com.skype.Call;
import com.skype.CallStatusChangedListener;
import com.skype.CommandFailedException;



public class SkypeTransfer extends Thread implements CallStatusChangedListener
{
	private String[] skypeTargets=null;
	private Logger log = null;
	private Call skypeCall=null;
	private volatile boolean tranferSuccess=false;
	private int timeoutMs=3000;
	private boolean callInterrupted=false;
	
	SkypeTransfer(Call argCall,String[] argSkypeTargets,int argTransferTimeoutMs) 
	{
		this.setName(this.getClass().getName()+".T"+this.getName().replaceAll("Thread-", ""));
		log = Logger.getLogger(this.getName());
		skypeTargets=argSkypeTargets;
		skypeCall=argCall;
		skypeCall.addCallStatusChangedListener(this);
		timeoutMs=argTransferTimeoutMs;
		start();
	}

	public void statusChanged(Call.Status status)
	{
		log.info("SkypeTransfer - statusChanged: "+status);

		if (status==Call.Status.CANCELLED || status==Call.Status.MISSED || status==Call.Status.REFUSED || status==Call.Status.FAILED || status==Call.Status.BUSY)
		{	
			callInterrupted=true;
			this.interrupt();
			return;
		}
		
		if (status==Call.Status.TRANSFERRED)
			tranferSuccess=true;
	}	
	
	public void run() 
	{
		int chkTime=100;
		int chkLimit=timeoutMs/chkTime;
		try
		{
 			for (int i=0;i<skypeTargets.length;i++)
 			{	
 				if (skypeTargets[i].length()>0)
 				{	
			 		log.info("Attempting Transfer of Skype Call to: "+skypeTargets[i]);
			 		if (skypeCall.canTransferTo(skypeTargets[i]))
			 		{	
			 			skypeCall.transferTo(skypeTargets[i]);
			 			log.info("SkypeTransfer waiting for transfer status");
			 			
			 			int attemptCnt=0;
			 			while (!tranferSuccess)
			 			{
			 				if (attemptCnt++>chkLimit || !skypeCall.canTransferTo(skypeTargets[i]))
			 				{	
			 					log.info("SkypeTransfer timeout");
			 					break;
			 				}
			 				sleep(100);
			 			}
			 			
			 			if (tranferSuccess)
			 			{
			 				skypeCall.finish();
			 				log.info("Successful transfer to: "+skypeTargets[i]);
			 				break;
			 			}
			 		}
			 		else
			 		{	
			 			log.error("canTransferTo returned false");
			 		}
 				}
 			}

 			if (!tranferSuccess)
 			{	
	 		  log.info("Rejecting Skype Call - Transfer failed.");
	 		  skypeCall.cancel();
 			}
		}	
	    catch (CommandFailedException e)
		{
			 String msg=e.getLocalizedMessage();
			 if (msg==null || !msg.contains("Cannot hangup inactive call"))
				 log.error("SkypeTransfer CommandFailedException",e);
		}
	    catch(Exception e)
	    {
	    	if (callInterrupted)
				log.info("SkypeTransfer aborted");
	    	else
	    	    log.error("SkypeTransfer exception",e);
	    }
		
 		skypeCall.removeCallStatusChangedListener(this);
	}
}
