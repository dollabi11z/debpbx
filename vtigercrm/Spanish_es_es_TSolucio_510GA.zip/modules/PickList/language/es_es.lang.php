<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *
 ********************************************************************************/
/**
 * this file can be used to internationalise the strings present in the picklist
 */
$mod_strings = array(
	'LBL_ASSIGN_BUTTON'=>'Asignar',
	'ADD_PICKLIST_VALUES'=>'Añadir valores de selección',
	'LBL_EXISTING_PICKLIST_VALUES'=>'Valores de selección actuales',
	'LBL_PICKLIST_ADDINFO'=>'Añade nuevos valores a continuación',
	'LBL_SELECT_ROLES'=>'Selecciona roles',
	'LBL_NON_EDITABLE_PICKLIST_ENTRIES'=>'Valores No-editables',
	'EDIT_PICKLIST_VALUE'=>'Edita valores selección',
	'LBL_EDIT_HERE'=>'Sustituir con: ',
	'LBL_SELECT_TO_EDIT'=>'Selecciona un valor para editar: ',
	'DELETE_PICKLIST_VALUES'=>'Elimina valores de selección',
	'LBL_REPLACE_WITH'=>'Reemplazar con: ',
	'ASSIGN_PICKLIST_VALUES'=>'Asigna valores de selección',
	'LBL_PICKLIST_VALUES'=>'Valores de selección disponibles',
	'LBL_PICKLIST_VALUES_ASSIGNED_TO'=>'Asigna valores de selección para ',
	'LBL_ADD_TO_OTHER_ROLES'=>'Añade a otros roles',
	'LBL_OK_BUTTON_LABEL'=>'Vale',
	'LBL_SELECT_ROLES'=>'Selecciona roles',
        'LBL_DISPLAYED_VALUES'=>'Los valores accesibles por el rol están abajo',
);
?>
