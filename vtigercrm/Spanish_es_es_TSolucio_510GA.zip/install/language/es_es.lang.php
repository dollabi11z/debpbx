<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * Portions created by TSolucio are Copyright (C) TSolucio.
 * All Rights Reserved.
 ************************************************************************************/

$optionalModuleStrings = array(
		'CustomerPortal_description'=>'Configuración del comportamiento del Portal del Cliente',
		'FieldFormulas_description'=>'Configuración de Fórmulas de actualización de campos personalizados',
		'RecycleBin_description'=>'Módulo de control de entidades eliminadas, permite restaurar y eliminar definitivamente',
		'Tooltip_description'=>'Configuración de ayudas de campos',
		'Webforms_description'=>'Soporte para webforms',
	);
?>
