<?php
#
#   HMMMMI              MI       MMMMI    MMMMM.  MMI    MM
#   HM: IMMM            MI       MM IMMM  MM  MMM  MM.  MMI
#   HM:    MM   MMMMM   MIMMMM   MM   MM  MM   MM   MM MMI
#   HM:     MM MM   MM  MM   MM  MM   MM  MMMMMM     MMM.
#   HM:     MM:MMMMMMM  MI   MM  MMMMMM   MM   MM:   MMM:
#   HM:    MM .MM       MI   MM  MM       MM    MM  MM MMM
#   HM: IMMM   MMM  HM  MM  MMI  MM       MM  MMM  MM   MMI
#   HMMMMI      .MMMM   MHMMM    MM       MMMMM   MM     MM
#
#                                            www.debpbx.org
#
# $ID: contacto.php, v 0.1  2009/12/01 00:00:00 federico Exp $
#
# DebPBX Panel - Version 0.1 
# Author: Federico Pereira <fpereira@debpbx.org> & Ramses Aguirre <raguirre@debpbx.org> 
# Copyright 2008 DebPBX - Federico Pereira (LordBaseX)
# Content-Type: text/plain; charset=UTF-8
# This script is licensed under GNU GPL version 2.0
#
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
<title></title>
<link rel="stylesheet" href="jqtransformplugin/jqtransform.css" type="text/css" media="all" />
<link rel="stylesheet" href="demo.css" type="text/css" media="all" />

<script type="text/javascript" src="../js/jquery-min.js" ></script>
<script type="text/javascript" src="jqtransformplugin/jquery.jqtransform.js" ></script>
<script language="javascript">
		$(function(){
			$('form').jqTransform({imgPath:'jqtransformplugin/img/'});
		});
</script>

</head>
<body>
<!--Pagina de contacto -->
<form action="enviar.php" method="POST">
  <table width="520" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="188"><label>Nombre completo:</label></td>
    <td width="332"><div class="rowElem"><input type="text" name="usuario"/></div></td>
  </tr>
  <tr>
    <td>Email:</td>
    <td><div class="rowElem"><input type="text" name="email"/></div></td>
  </tr>
  <tr>
    <td>Página en cuestion:</td>
    <td><div class="rowElem"><input type="text" name="username"/></div></td>
  </tr>
  <tr>
    <td>
    Razon</td>
    <td>
    <div class="rowElem">
    <select name="razon" > 
 		<option value="opt1">Notificación de bugs</option> 
		<option value="opt2">Sugerencias para posteriores versiones</option> 
		<option value="opt3">Deseo una cotización para configuración de DebPBX</option> 
		<option value="opt4">Deseo una cotización para soporte técnico</option> 
		<option value="opt5">Departamento de prensa</option> 
		<option value="opt6">RRHH</option>
        <option value="opt7">Otras ...</option>
	</select> 
    </div>
    </td>
  </tr>
  <tr>
    <td><p>Comentarios:</p>
      <p><img src="../img/contacto.jpg" width="160" height="160" /></p></td>
    <td><div class="rowElem"><textarea name="razones" cols="40" rows="12"></textarea></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div class="rowElem"><input type="submit" value="Enviar" /></div></td>
  </tr>
</table>

</form>
</body>
</html>
