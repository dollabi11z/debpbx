<?php
#
#   HMMMMI              MI       MMMMI    MMMMM.  MMI    MM
#   HM: IMMM            MI       MM IMMM  MM  MMM  MM.  MMI
#   HM:    MM   MMMMM   MIMMMM   MM   MM  MM   MM   MM MMI
#   HM:     MM MM   MM  MM   MM  MM   MM  MMMMMM     MMM.
#   HM:     MM:MMMMMMM  MI   MM  MMMMMM   MM   MM:   MMM:
#   HM:    MM .MM       MI   MM  MM       MM    MM  MM MMM
#   HM: IMMM   MMM  HM  MM  MMI  MM       MM  MMM  MM   MMI
#   HMMMMI      .MMMM   MHMMM    MM       MMMMM   MM     MM
#
#                                            www.debpbx.org
#
# $ID: enviar.php, v 0.1  2009/12/01 00:00:00 federico Exp $
#
# DebPBX Panel - Version 0.1 
# Author: Federico Pereira <fpereira@debpbx.org> & Ramses Aguirre <raguirre@debpbx.org> 
# Copyright 2008 DebPBX - Federico Pereira (LordBaseX)
# Content-Type: text/plain; charset=UTF-8
# This script is licensed under GNU GPL version 2.0
#
//error_reporting(E_ALL);
error_reporting(E_STRICT);

date_default_timezone_set('America/Toronto');
include("class.phpmailer.php");

$user_contact  = $_POST['usuario'];
$mail_contact  = $_POST['email'];
$info_contact  = $_POST['razon'];
$body_contact  = $_POST['razones'];

$mail = new PHPMailer();
$mail->Host = "localhost";

$mail->From = "info@debpbx.org";
$mail->FromName = "Nombre del Remitente";
$mail->Subject = "Subject del correo";
$mail->AddAddress("info@debpbx.org","DebPBX Panel");

$body             = $body_contact;
$mail->From       = $mail_contact;
$mail->FromName   = $user_contact;
$mail->Subject    = "Contacto via Panel DebPBX";

$mail->IsHTML(true);


if(!$mail->Send()) {
  echo "Error al enviar el correo: " . $mail->ErrorInfo;
} else {
  echo "Correo enviado!";
}

?>
