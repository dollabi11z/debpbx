<?php
#
#   HMMMMI              MI       MMMMI    MMMMM.  MMI    MM
#   HM: IMMM            MI       MM IMMM  MM  MMM  MM.  MMI
#   HM:    MM   MMMMM   MIMMMM   MM   MM  MM   MM   MM MMI
#   HM:     MM MM   MM  MM   MM  MM   MM  MMMMMM     MMM.
#   HM:     MM:MMMMMMM  MI   MM  MMMMMM   MM   MM:   MMM:
#   HM:    MM .MM       MI   MM  MM       MM    MM  MM MMM
#   HM: IMMM   MMM  HM  MM  MMI  MM       MM  MMM  MM   MMI
#   HMMMMI      .MMMM   MHMMM    MM       MMMMM   MM     MM
#
#                                            www.debpbx.org
#
# $ID: index.php, v 0.1  2009/12/01 00:00:00 federico Exp $
#
# DebPBX Panel - Version 0.1 
# Author: Federico Pereira <fpereira@debpbx.org> & Ramses Aguirre <raguirre@debpbx.org> 
# Copyright 2008 DebPBX - Federico Pereira (LordBaseX)
# Content-Type: text/plain; charset=UTF-8
# This script is licensed under GNU GPL version 2.0
#
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="debpbx, debian, lenny 5.X, asterisk, open source, argentina, a2billing, freepbx, bind9, postfix, digium, vtigercrm , iaxmodem, iax, sip, h323, openh323" />
<meta name="title" content="Proyecto DebPBX" />
<meta name="author" content="Federico Pereira" />
<meta name="description" content="DebPBX es una plataforma de software libre (bajo licencia GPL) basada en Asterisk que proporciona funcionalidades de una central telefónica (PBX). Como cualquier PBX, se puede conectar un número determinado de teléfonos para hacer llamadas entre sí e incluso conectar a un proveedor de VoIP o bien a una ISDN(RDSI) tanto básicos como primarios." />
<meta name="generator" content="DebPBX Panel 1.2.10 - ...because open source is the future" />
<title>::DebPBX - Panel::</title>
<link rel="shortcut icon" href="/favicon.ico">

<link href="css/common.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="css/template.css" rel="stylesheet" type="text/css" />

<link type="text/css" media="screen" rel="stylesheet" href="colorbox.css" />
<style type="text/css">
<!--
       .contacto img {
            position: absolute;
            top:  351px;
            left: 270px;
            border: none;
        }
       
    -->
</style>
<script type="text/javascript" src="js/jquery-min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox.js"></script>
<script type="text/javascript">
    <!--
$(document).ready(function(){
			// Activa el Botton de contacto
            $(".contacto").hover(function(){
                $(".contacto img")
                .animate({top:"355px"}, 200).animate({top:"345px"}, 200) // first jump
                .animate({top:"355px"}, 100).animate({top:"345px"}, 100) // second jump
                .animate({top:"355px"}, 100).animate({top:"350px"}, 100); // the last jump
            });
			// Ventanas
			$(".contacto").colorbox({iframe:true, width:600, height:565});
			$("#click").click(function(){ 
			   $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
        }); 
    //-->
</script>
<style type="text/css">
     
</style>
</head>
<body>
<div id="layout">
  <div id="header"><a href="http://www.debpbx.org" target="_blank"><img src="img/logo.png" border="0"></a></div>	
  <div id="top_shadow"></div>
  <div id="content">
    <div id="panel_botones">
      <div id="panel_opciones">
        <div class="moduletable_text" id="Mod61">
          <h3 class="clearfix">Acerca del Proyecto</h3>
          <div class="ja-box-ct clearfix">
            <div class="ja-innerdiv clearfix">
              <div class="img_caption"><img src="img/debian.png" border="0" alt="Sample Images" /></div>
              <p>DebPBX es una plataforma de software libre (bajo licencia GPLv2) basada en Debian y Asterisk. Proporciona la función de una central telefónica IP (PBX).</p>
              <p>&nbsp;</p>
              <br /><br />
              <a class="contacto" href="contacto/contacto.php" title="CONTACTO EMAIL - Copyright 2009 DebPBX">
        	  <img src="img/Mail.png" alt="" /></a>
			  <br />
			  <br />
            </div>
          </div>
        </div>
      </div>
      <div id="botones">
        
        <a href="munin"><img src="botones/info-sistema.png" hspace="5" vspace="5" border="0" /></a> <a href="panel"><img src="botones/fop.png" hspace="5" vspace="5" border="0" /></a> <a href="admin/reports.php"><img src="botones/cdr.png" hspace="5" vspace="5" border="0" /></a> <a href="recordings"><img src="botones/recordings.png" hspace="2" vspace="2" border="0" /></a> <br />
        <a href="avantfax"><img src="botones/virtualfax.png" hspace="5" vspace="5" border="0" /></a> <a href="#"></a> <a href="vtigercrm"><img src="botones/crm.png" hspace="5" vspace="5" border="0" /></a><!-- AAH ADD-ONS -->
        <a href="phpmyadmin"></a> <a href="phpmyadmin"><img src="botones/basededatos.png" hspace="5" vspace="5" border="0" /></a> <a href="#"></a><!-- AAH END-USER TOOLS -->
        <a href="freepbx"></a><a href="admin"><img src="botones/amp.png" hspace="5" vspace="5" border="0" /></a></div>
      <p>&nbsp;</p>
    </div>
  </div>
  <div id="bottom_shadow">
  </div>
  <div id="footer">
	<div class="copyright">
		<span class="copy_char">&copy;</span> 2009 debpbx.org<br />
	</div>
   	<div class="lang_switch">Powered by <a href="http://www.debpbx.org" target="_blank">DebPBX</a></div>
  </div>
</div>
</body>
</html>