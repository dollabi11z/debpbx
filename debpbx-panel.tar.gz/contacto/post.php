<?php
#
#   HMMMMI              MI       MMMMI    MMMMM.  MMI    MM
#   HM: IMMM            MI       MM IMMM  MM  MMM  MM.  MMI
#   HM:    MM   MMMMM   MIMMMM   MM   MM  MM   MM   MM MMI
#   HM:     MM MM   MM  MM   MM  MM   MM  MMMMMM     MMM.
#   HM:     MM:MMMMMMM  MI   MM  MMMMMM   MM   MM:   MMM:
#   HM:    MM .MM       MI   MM  MM       MM    MM  MM MMM
#   HM: IMMM   MMM  HM  MM  MMI  MM       MM  MMM  MM   MMI
#   HMMMMI      .MMMM   MHMMM    MM       MMMMM   MM     MM
#
#                                            www.debpbx.org
#
# $ID: post.php, v 0.1  2009/12/01 00:00:00 federico Exp $
#
# DebPBX Panel - Version 0.1 
# Author: Federico Pereira <fpereira@debpbx.org> & Ramses Aguirre <raguirre@debpbx.org> 
# Copyright 2008 DebPBX - Federico Pereira (LordBaseX)
# This script is licensed under GNU GPL version 2.0
#
include_once('../class.phpmailer.php');

$user_contact  = $_POST['usuario'];
$mail_contact  = $_POST['email'];
$body_contact  = $_POST['razones'];

$mail             = new PHPMailer();
$body             = $body_contact;

$mail->From       = $mail_contact;
$mail->FromName   = $user_contact;
$mail->Subject    = "Contacto via DebPBX Panel";

$mail->IsHTML(true);
$mail->AddAddress("info@debpbx.org", "DebPBX");


if(!$mail->Send()) {
  echo "Error de envio: " . $mail->ErrorInfo;
} else {
  echo "Mensaje enviado!";
}

?>
